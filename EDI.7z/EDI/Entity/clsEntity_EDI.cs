﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDI.Entity
{
    public class clsEntity_EDI
    {
        public string EDIFormat  { get; set; }
        public string FileName { get; set; }
        public int RecordCount_846 { get; set; }
        public int RecordCount_867 { get; set; }

    }
}