﻿using System;
using System.Collections.Generic;
using System.Data;
using System.Data.SqlClient;
using System.Globalization;
using System.IO;
using System.Linq;
using System.Reflection;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
namespace EDI.Classes
{
    public class clsDataAccess
    {
        #region Variables
        private SqlConnection conn;
        #endregion

        #region Constructor

        public clsDataAccess()
        {
        }

        #endregion

        #region Database Method

        public SqlConnection OpenConnection()
        {
            try
            {
                //SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(GetSQLConnectionString());
                //string sqlconnstring = @"Data Source=" + builder.DataSource + ";Initial Catalog=" + builder.InitialCatalog + ";User ID=" + builder.UserID + ";Password=" + builder.Password + "";
                conn = new SqlConnection();
                conn.ConnectionString = GetSQLConnectionString();
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return conn;
        }

        private void CloseConnection(SqlConnection conn)
        {
            conn.Close();
        }

        public List<T> ConvertTo<T>(DataTable datatable) where T : new()
        {
            List<T> Temp = new List<T>();
            try
            {
                List<string> columnsNames = new List<string>();
                foreach (DataColumn DataColumn in datatable.Columns)
                    columnsNames.Add(DataColumn.ColumnName);
                Temp = datatable.AsEnumerable().ToList().ConvertAll<T>(row => getObject<T>(row, columnsNames));
                return Temp;
            }
            catch
            {
                return Temp;
            }
        }

        public T getObject<T>(DataRow row, List<string> columnsName) where T : new()
        {
            T obj = new T();
            try
            {
                string columnname = "";
                string value = "";
                PropertyInfo[] Properties;
                Properties = typeof(T).GetProperties();
                foreach (PropertyInfo objProperty in Properties)
                {
                    columnname = columnsName.Find(name => name.ToLower() == objProperty.Name.ToLower());
                    if (!string.IsNullOrEmpty(columnname))
                    {
                        value = row[columnname].ToString();
                        if (!string.IsNullOrEmpty(value))
                        {
                            if (Nullable.GetUnderlyingType(objProperty.PropertyType) != null)
                            {
                                value = row[columnname].ToString().Replace("$", "").Replace(",", "");
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(Nullable.GetUnderlyingType(objProperty.PropertyType).ToString())), null);
                            }
                            else
                            {
                                value = row[columnname].ToString();
                                objProperty.SetValue(obj, Convert.ChangeType(value, Type.GetType(objProperty.PropertyType.ToString())), null);
                            }
                        }
                    }
                }
                return obj;
            }
            catch
            {
                return obj;
            }
        }

        private T BindData_ToClass<T>(DataTable dt)
        {
            DataRow dr = dt.Rows[0];

            // Get all columns' name
            List<string> columns = new List<string>();
            foreach (DataColumn dc in dt.Columns)
            {
                columns.Add(dc.ColumnName);
            }

            // Create object
            var ob = Activator.CreateInstance<T>();

            // Get all fields
            var fields = typeof(T).GetFields();
            foreach (var fieldInfo in fields)
            {
                if (columns.Contains(fieldInfo.Name))
                {
                    // Fill the data into the field
                    fieldInfo.SetValue(ob, dr[fieldInfo.Name]);
                }
            }

            // Get all properties
            var properties = typeof(T).GetProperties();
            foreach (var propertyInfo in properties)
            {
                if (columns.Contains(propertyInfo.Name))
                {
                    // Fill the data into the property
                    propertyInfo.SetValue(ob, dr[propertyInfo.Name]);
                }
            }

            return ob;
        }

        public DataSet FillDataset(string Query, SqlConnection conn)
        {
            DataSet ods = new DataSet();
            SqlCommand cmd = null;
            SqlDataAdapter da = null;

            try
            {
                cmd = new SqlCommand(Query, conn);
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch
            {
                //MessageBox.Show(ex.Message);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (ods != null)
                {
                    ods.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (da != null)
                {
                    da.Dispose();
                }
            }
            return ods;

        }

        public string GetRecord(string query)
        {
            string Value = "";
            SqlDataReader dr = null;
            SqlCommand cmd = null;
            conn = OpenConnection();
            conn.Open();
            try
            {
                cmd = new SqlCommand(query, conn);

                dr = cmd.ExecuteReader();
                if (dr.HasRows)
                {
                    dr.Read();
                    Value = dr[0].ToString();
                }
                if (dr != null)
                {
                    dr.Close();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                return Value;
            }
            catch (Exception ex)
            {
                return ex.Message;
            }
        }

        public void CheckDBConnection()
        {
            conn = OpenConnection();
            conn.Open();
        }

        public DataTable FillDataTable_Params(string commandText, CommandType commandType, out string message, params SqlParameter[] parameters)
        {
            message = string.Empty;
            DataTable ods = new DataTable();
            SqlDataAdapter da = null;
            SqlCommand cmd = null;
            try
            {
                cmd = new SqlCommand();
                if (parameters != null)
                {
                    cmd.Parameters.AddRange(parameters);
                }
                cmd.CommandType = commandType;
                cmd.CommandText = commandText;
                cmd.Connection = OpenConnection();
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                WriteLog(message);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (ods != null)
                {
                    ods.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (da != null)
                {
                    da.Dispose();
                }
            }
            return ods;

        }

        public DataSet FillDataset_Params(string commandText, CommandType commandType, out string message, params SqlParameter[] parameters)
        {
            message = string.Empty;
            DataSet ods = new DataSet();
            SqlDataAdapter da = null;
            SqlCommand cmd = null;
            try
            {

                cmd = new SqlCommand();
                cmd.Parameters.AddRange(parameters);
                cmd.CommandType = commandType;
                cmd.CommandText = commandText;
                cmd.Connection = OpenConnection();
                da = new SqlDataAdapter(cmd);
                da.Fill(ods);
                return ods;
            }
            catch (Exception ex)
            {
                message = ex.Message;
                WriteLog(message);
            }
            finally
            {
                if (conn != null && conn.State == ConnectionState.Closed)
                {
                    conn.Close();
                }
                if (ods != null)
                {
                    ods.Dispose();
                }
                if (cmd != null)
                {
                    cmd.Dispose();
                }
                if (da != null)
                {
                    da.Dispose();
                }
            }
            return ods;

        }

        #region Commented

        /* Stored Proceudre With SQL Parameters Example
         * http://www.c-sharpcorner.com/forums/generic-method-to-add-sql-parameters-dynamically-for-executing-sql-parameterized-query-for-adonet
         DataSet FetchData(SqlConnection connection, string queryText, params SqlParameter[] parameters)
           {
              // ...    
              command.Parameters.Clear(); // if needed 
              command.Parameters.AddRange(parameters);
              // ... 
           }

        and then call it, for example, with something like this:

          SqlParameter param1 = new SqlParameter("Name", SqlDbType.VarChar);
          param1.Value = "Mahesh";
          SqlParameter param2 = new SqlParameter("Id", SqlDbType.Int);
          param1.Value = 1;

          DataSet ds = FetchData(conn, queryText, param1, param2);
         */

        #endregion

        #endregion

        #region Get Database Name

        public string GetDBName()
        {
            SqlConnectionStringBuilder builder = new SqlConnectionStringBuilder(GetSQLConnectionString());
            return builder.InitialCatalog;
        }

        private string GetSQLConnectionString()
        {
            return System.Configuration.ConfigurationManager.ConnectionStrings["EDIConnectionString"].ToString();

        }

        #endregion

        public void WriteLog(string message)
        {
            string filePath = Application.StartupPath + "\\" + "log.txt";
            using (StreamWriter writer = new StreamWriter(filePath, true))
            {
                string seed = DateTime.Now.ToString("dd-MM-yyyy") + "_" + Convert.ToString(DateTime.Now.TimeOfDay);
                writer.WriteLine(seed + " :: " + message);
                writer.Close();
            }
        }

    }
}
