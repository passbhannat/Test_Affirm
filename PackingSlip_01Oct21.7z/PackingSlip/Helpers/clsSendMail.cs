using General.Classes;
using System;
using System.Collections.Generic;
using System.Data;
using System.Linq;
using System.Net.Mail;
using System.Text;
using System.Threading.Tasks;

namespace General
{
    public class clsSendMail
    {
        public bool sendMail(string to, string from, string cc, string bcc, string sub, string body, string attachment, out string errorMessage)
        {
            errorMessage = string.Empty;
            System.Net.Mail.MailMessage Email = new System.Net.Mail.MailMessage();

            if (to != "")
            {
                Email.To.Add(to);
            }
            if (cc != "")
            {
                Email.CC.Add(cc);
            }
            if (bcc != "")
            {
                Email.Bcc.Add(bcc);
            }
            try
            {
                Email.Subject = sub;
                Email.IsBodyHtml = true;
                Email.Body = body;

                SmtpClient smtpClient = new SmtpClient();
                Email.From = new System.Net.Mail.MailAddress(ConfigManager.GetFromMail());
                smtpClient.Host = ConfigManager.GetSMTP_Host();// "AM0PR04CA0002.eurprd04.prod.outlook.com"; //ConfigManager.GetSMTP_Host();
                smtpClient.Port = ConfigManager.GetSMTP_Port();
                smtpClient.UseDefaultCredentials = false;
                if (attachment != string.Empty)
                {
                    System.Net.Mime.ContentType contentType = new System.Net.Mime.ContentType();
                    contentType.MediaType = System.Net.Mime.MediaTypeNames.Application.Octet;
                    contentType.Name = System.IO.Path.GetFileName(attachment);
                    Email.Attachments.Add(new Attachment(attachment, contentType));
                }
                //smtpClient.Credentials = new System.Net.NetworkCredential(ConfigManager.GetSMTP_Username(), ConfigManager.GetSMTP_Password());
                //smtpClient.EnableSsl = true;
                //smtpClient.TargetName = "STARTTLS/smtp.office365.com";

                try
                {
                    smtpClient.Send(Email);
                }
                catch (SmtpFailedRecipientsException ex)
                {
                    errorMessage = ex.Message;
                    return false;
                }
            }
            catch (System.Net.Mail.SmtpException se)
            {
                errorMessage = se.Message;
                return false;
            }
            return true;
        }


        //public List<clsEntity_EmailTemplate> Get_EmailTemplate(int TemplateTriggerId, string dbName)
        //{
        //    clsSendMailDAL _dAL = new clsSendMailDAL();
        //    List<clsEntity_EmailTemplate> _clsEntity_EmailTemplate = _dAL.Get_EmailTemplate(TemplateTriggerId, dbName);
        //    return _clsEntity_EmailTemplate;
        //}
    }
}
