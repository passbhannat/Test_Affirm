﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace EDI.Classes
{
    public static class ConfigManager
    {
        public static string GetEDI846_SheetName()
        {
            return ConfigurationManager.AppSettings["EDI846_SheetName"].ToString();
        }

        public static string GetEDI867_SheetName()
        {
            return ConfigurationManager.AppSettings["EDI867_SheetName"].ToString();
        }

        public static string GetTempFolderPath()
        {
            return ConfigurationManager.AppSettings["TempFolderPath"].ToString();
        }

        public static string GetDestinationFolderName()
        {
            return ConfigurationManager.AppSettings["Destination_FolderName"].ToString();
        }

        public static string GetProcessedFolderName()
        {
            return ConfigurationManager.AppSettings["Processed_FolderName"].ToString();
        }

        public static string GetEnvironment()
        {
            return ConfigurationManager.AppSettings["Environment"].ToString();
        }

        public static string GetSource_Location()
        {
            return ConfigurationManager.AppSettings["Source_Location"].ToString();
        }

        public static string GetSource_LocalPath()
        {
            return ConfigurationManager.AppSettings["Source_LocalPath"].ToString();
        }

        public static string GetSource_FolderName()
        {
            return ConfigurationManager.AppSettings["Source_FolderName"].ToString();
        }

        public static string GetSource_Host()
        {
            return ConfigurationManager.AppSettings["Source_Host"].ToString();
        }

        public static string GetSource_Username()
        {
            return ConfigurationManager.AppSettings["Source_Username"].ToString();
        }

        public static string GetSource_Password()
        {
            return ConfigurationManager.AppSettings["Source_Password"].ToString();
        }

        public static int GetSource_Port()
        {
            return int.Parse(ConfigurationManager.AppSettings["Source_Port"].ToString());
        }

        public static string GetDestination_Host()
        {
            return ConfigurationManager.AppSettings["Destination_Host"].ToString();
        }

        public static string GetDestination_Username()
        {
            return ConfigurationManager.AppSettings["Destination_Username"].ToString();
        }

        public static string GetDestination_Password()
        {
            return ConfigurationManager.AppSettings["Destination_Password"].ToString();
        }

        public static int GetDestination_Port()
        {
            return int.Parse(ConfigurationManager.AppSettings["Destination_Port"].ToString());
        }

        public static string GetSMTP_Host()
        {
            return ConfigurationManager.AppSettings["SMTP_Host"].ToString();
        }

        

        public static string GetSMTP_Username()
        {
            return ConfigurationManager.AppSettings["SMTP_Username"].ToString();
        }

        public static string GetSMTP_Password()
        {
            return ConfigurationManager.AppSettings["SMTP_Password"].ToString();
        }

        public static int GetSMTP_Port()
        {
            return int.Parse(ConfigurationManager.AppSettings["SMTP_Port"].ToString());
        }

        public static string GetFromMail()
        {
            return ConfigurationManager.AppSettings["FromMail"].ToString();
        }

        public static string GetToMail()
        {
            return ConfigurationManager.AppSettings["ToMail"].ToString();
        }

        public static string GetISAReceiverID()
        {
            return ConfigurationManager.AppSettings["ISAReceiverID"].ToString();
        }

        public static string GetISASenderID()
        {
            return ConfigurationManager.AppSettings["ISASenderID"].ToString();
        }

        public static string GetGSReceiverID_WD()
        {
            return ConfigurationManager.AppSettings["GSReceiverID_WD"].ToString();
        }

        public static string GetGSReceiverID_SANDISK()
        {
            return ConfigurationManager.AppSettings["GSReceiverID_SANDISK"].ToString();
        }

        public static string GetGSReceiverID_HGST()
        {
            return ConfigurationManager.AppSettings["GSReceiverID_HGST"].ToString();
        }

        public static string GetWarehouseCode()
        {
            return ConfigurationManager.AppSettings["WarehouseCode"].ToString();
        }

        public static string GetEDIContactPersonName()
        {
            return ConfigurationManager.AppSettings["EDIContactPersonName"].ToString();
        }

        public static string GetEDIContactPersonEmailID()
        {
            return ConfigurationManager.AppSettings["EDIContactPersonEmailID"].ToString();
        }

        public static string GetEDISeperator()
        {
            return ConfigurationManager.AppSettings["EDISeperator"].ToString();
        }

        public static string GetEDIEndTag()
        {
            return ConfigurationManager.AppSettings["EDIEndTag"].ToString();
        }

        public static string GetN3Address()
        {
            return ConfigurationManager.AppSettings["N3Address"].ToString();
        }

        public static string GetN4City()
        {
            return ConfigurationManager.AppSettings["N4City"].ToString();
        }

        public static string GetN4ZipCode()
        {
            return ConfigurationManager.AppSettings["N4ZipCode"].ToString();
        }

    }
}
