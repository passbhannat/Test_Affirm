﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace General.Classes
{
    public class clsItemEntity
    {
        public string LineId { get; set; }

        public string ItemCode { get; set; }

        public string ItemName { get; set; }

        public string WhsCode { get; set; }

        public string BarCode { get; set; }

        public string Qty { get; set; }

        public string Batch { get; set; }
    }
}
