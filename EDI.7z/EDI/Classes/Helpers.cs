﻿using EDI.Entity;
using System;
using System.ComponentModel;
using System.Data;
using System.Data.OleDb;
using System.Data.SqlClient;
using System.IO;
using System.Text;
using System.Windows.Forms;

namespace EDI.Classes
{
    public class Helpers : clsDataAccess
    {
        public bool ReadExcelFile(string filePath, string sheetName, out DataTable dtExcel)
        {
            dtExcel = new DataTable();
            try
            {
                string fileExtension = System.IO.Path.GetExtension(filePath);

                if (fileExtension == ".xls" || fileExtension == ".xlsx" || fileExtension == ".xlsm")
                {
                    string excelConnectionString = string.Empty;
                    excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    if (fileExtension == ".xls")
                    {
                        excelConnectionString = "Provider=Microsoft.Jet.OLEDB.4.0;Data Source=" + filePath + ";Extended Properties=\"Excel 8.0;HDR=Yes;IMEX=1\"";
                    }
                    else if (fileExtension == ".xlsx" || fileExtension == ".xlsm")
                    {
                        excelConnectionString = "Provider=Microsoft.ACE.OLEDB.12.0;Data Source=" + filePath + ";Extended Properties=\"Excel 12.0;HDR=Yes;IMEX=1\"";
                    }

                    DataTable sheets = GetSchemaTable(excelConnectionString);

                    OleDbConnection excelConnection1 = new OleDbConnection(excelConnectionString);
                    string query = "Select * from [" + sheetName + "$]";
                    using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, excelConnection1))
                    {
                        dataAdapter.Fill(dtExcel);
                        dataAdapter.Dispose();
                    }
                    //for (int i = 0; i < sheets.Rows.Count; i++)
                    //{
                    //    DataTable dt = new DataTable();

                    //    string query = "Select * from [" + sheets.Rows[i]["TABLE_NAME"].ToString() + "]";
                    //    using (OleDbDataAdapter dataAdapter = new OleDbDataAdapter(query, excelConnection1))
                    //    {
                    //        dataAdapter.Fill(dt);
                    //        dataAdapter.Dispose();
                    //        dsExcel.Tables.Add(dt);
                    //    }
                    //}
                    excelConnection1.Close();
                    excelConnection1.Dispose();
                }
                return true;
            }
            catch (Exception ex)
            {
                return false;
            }
        }

        private DataTable GetSchemaTable(string connectionString)
        {
            using (OleDbConnection connection = new
                       OleDbConnection(connectionString))
            {
                connection.Open();
                DataTable schemaTable = connection.GetOleDbSchemaTable(
                    OleDbSchemaGuid.Tables,
                    new object[] { null, null, null, "TABLE" });
                return schemaTable;
            }
        }

        public bool Generate_846(DataTable dsExcel, string destinationFolderName, out string errorDescription, out string ediFilepath, out int recordProcessed)
        {
            errorDescription = "";
            recordProcessed = 0;
            int inventoryTable = 0;
            string seed = DateTime.Now.ToString("dd-MM-yyyy") + "_" + Convert.ToString((int)DateTime.Now.Ticks);
            string fileName = "edi_846_" + seed.ToString() + ".edi";
            string separator = ConfigManager.GetEDISeperator();
            string endTag = ConfigManager.GetEDIEndTag();
            clsEntity_EDI846 _edi = new clsEntity_EDI846();
            int headerRowNo = 0;
            StringBuilder stringBuilder = new StringBuilder();
            ediFilepath = destinationFolderName + "\\" + fileName;
            try
            {
                using (StreamWriter writer = new StreamWriter(ediFilepath, true))
                {
                    string ISADate = DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string date = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string time = DateTime.Now.ToString("HHMM");
                    DataTable dtInput = FillDataTable_Params("SELECT ElementName,ElementDefaultValue FROM EDIMapping_846", CommandType.Text, out string message, null);

                    //Transpose DataTable

                    DataTable dtEDI = GenerateTransposedTable(dtInput);
                    string value = "";

                    //Transaction Set Trailer
                    int SE_SegementCount = 0;

                    //Transaction Deals
                    int CTT_TransactionCount = 0;

                    // Set values
                    PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(_edi);
                    foreach (PropertyDescriptor property in properties)
                    {
                        try
                        {
                            if (property != null)
                            {
                                value = dtEDI.Rows[0][property.DisplayName].ToString();
                                Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                object safeValue = (value == null) ? null : Convert.ChangeType(value, t);
                                property.SetValue(_edi, safeValue);
                            }
                        }
                        catch { }
                    }

                    _edi.ISA06 = _edi.ISA06.PadRight(15, ' ');
                    _edi.ISA08 = _edi.ISA08.PadRight(15, ' ');
                    _edi.ISA09 = ISADate;
                    _edi.ISA10 = time;

                    _edi.GS04 = date;
                    _edi.GS05 = time;
                    _edi.BIA04 = date;

                    _edi.N102 = dsExcel.Rows[headerRowNo]["Partner Name"].ToString();//Distributer Name
                    _edi.N104_DS = dsExcel.Rows[headerRowNo]["Partner Code"].ToString();  //Identification Code  - Dynamic

                    _edi.GE02 = _edi.GS06;
                    _edi.IEA02 = _edi.ISA13;

                    #region Set EDI Segment

                    string spaceBetweenISA01_ISA03 = new string(' ', 10);
                    string spaceBetweenISA03_ZZ = new string(' ', 10);

                    stringBuilder.AppendLine("ISA" + separator + _edi.ISA01 + separator + spaceBetweenISA01_ISA03 + separator + _edi.ISA03 + separator + spaceBetweenISA03_ZZ + separator + "ZZ" + separator + _edi.ISA06 + separator + _edi.ISA05 + separator + _edi.ISA08 + separator + _edi.ISA09 + separator + _edi.ISA10 + separator + _edi.ISA11 + separator + _edi.ISA12 + separator + _edi.ISA13 + separator + _edi.ISA14 + separator + _edi.ISA15 + separator + _edi.ISA16 + endTag);
                    SE_SegementCount++;

                    //GS - Functional Group Header
                    stringBuilder.AppendLine("GS" + separator + _edi.GS01 + separator + _edi.GS02 + separator + _edi.GS03 + separator + _edi.GS04 + separator + _edi.GS05 + separator + _edi.GS06 + separator + _edi.GS07 + separator + _edi.GS08 + endTag);
                    SE_SegementCount++;

                    //ST - Transaction Set Header
                    stringBuilder.AppendLine("ST" + separator + _edi.ST01 + separator + _edi.ST02 + endTag);
                    SE_SegementCount++;

                    //BIA - Beginning Segment for Inventory Inquiry/Advice
                    stringBuilder.AppendLine("BIA" + separator + _edi.BIA01 + separator + _edi.BIA02 + separator + _edi.BIA03 + separator + _edi.BIA04 + endTag);
                    SE_SegementCount++;

                    //N1 - Name
                    stringBuilder.AppendLine("N1" + separator + "DS" + separator + _edi.N102 + separator + _edi.N103 + separator + _edi.N104_DS + endTag);
                    SE_SegementCount++;

                    //_edi.N104_WHS = ConfigManager.GetWarehouseCode();  //dsExcel.Rows[headerRowNo]["Warehouse Location"].ToString();
                    stringBuilder.AppendLine("N1" + separator + "WH" + separator + "Distributor WAREHOUSE" + separator + _edi.N103 + separator + _edi.N104_WHS + endTag);
                    SE_SegementCount++;

                    //N3 - Address Information
                    if (_edi.N301 != string.Empty)
                    {
                        stringBuilder.AppendLine("N3" + separator + _edi.N301 + endTag);
                        SE_SegementCount++;
                    }
                    //N4 - Geographic Location

                    _edi.N404 = dsExcel.Rows[headerRowNo]["Country"].ToString();

                    _edi.N401 = _edi.N401 == string.Empty ? "NA" : _edi.N401;
                    _edi.N402 = _edi.N402 == string.Empty ? "NA" : _edi.N402;
                    _edi.N403 = _edi.N403 == string.Empty ? "NA" : _edi.N403;
                    _edi.N404 = _edi.N404 == string.Empty ? "NA" : _edi.N404;

                    stringBuilder.AppendLine("N4" + separator + _edi.N401 + separator + _edi.N402 + separator + _edi.N403 + separator + _edi.N404 + endTag);
                    SE_SegementCount++;

                    int lineNo = 1;
                    for (int i = headerRowNo; i < dsExcel.Rows.Count; i++)
                    {
                        string quantity = dsExcel.Rows[i]["Quantity on Hand"].ToString();
                        if (quantity.ToString().ToLower() == "required")
                        {
                            continue;
                        }
                        //LIN - Item Identification
                        _edi.LIN01 = lineNo.ToString();
                        lineNo++;
                        _edi.LIN03 = dsExcel.Rows[i]["SanDisk Part Number"].ToString();

                        stringBuilder.AppendLine("LIN" + separator + _edi.LIN01 + separator + _edi.LIN02 + separator + _edi.LIN03 + endTag);
                        SE_SegementCount++;

                        //QTY - Quantity
                        _edi.QTY01 = "17";
                        quantity = dsExcel.Rows[i]["Quantity on Hand"].ToString();
                        double dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        _edi.QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + _edi.QTY01 + separator + _edi.QTY02 + separator + _edi.QTY03 + endTag);
                        SE_SegementCount++;

                        _edi.QTY01 = "27";
                        quantity = dsExcel.Rows[i]["Quantity in Backorder"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        _edi.QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + _edi.QTY01 + separator + _edi.QTY02 + separator + _edi.QTY03 + endTag);
                        SE_SegementCount++;

                        _edi.QTY01 = "76";
                        quantity = dsExcel.Rows[i]["Quantity Returned to SanDisk"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        _edi.QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + _edi.QTY01 + separator + _edi.QTY02 + separator + _edi.QTY03 + endTag);
                        SE_SegementCount++;

                        _edi.QTY01 = "63";
                        quantity = dsExcel.Rows[i]["Quantity on Order"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        _edi.QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + _edi.QTY01 + separator + _edi.QTY02 + separator + _edi.QTY03 + endTag);
                        SE_SegementCount++;
                        CTT_TransactionCount++;
                    }
                    //CTT - Transaction Totals
                    stringBuilder.AppendLine("CTT" + separator + CTT_TransactionCount + endTag);

                    //SE - Transaction Set Trailer
                    stringBuilder.AppendLine("SE" + separator + SE_SegementCount + separator + _edi.ST02 + endTag);

                    //GE - Functional Group Trailer
                    stringBuilder.AppendLine("GE" + separator + _edi.GE01 + separator + _edi.GE02 + endTag);

                    //IEA - Interchnage Control Trailer
                    stringBuilder.AppendLine("IEA" + separator + _edi.IEA01 + separator + _edi.IEA02 + endTag);

                    #endregion

                    writer.WriteLine(stringBuilder);
                    writer.Close();
                    recordProcessed = dsExcel.Rows.Count;

                    //Increment Control numbers
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_846 T0 WHERE ElementName = 'ST02'");
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_846 T0 WHERE ElementName = 'ISA13'");
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_846 T0 WHERE ElementName = 'GS06'");
                }
            }
            catch (Exception ex)
            {
                errorDescription = ex.Message;
                return false;
            }
            return true;
        }

        public bool Generate_867(DataTable dsExcel, string destinationFolderName, out string errorDescription, out string ediFilepath, out int recordProcessed)
        {
            errorDescription = "";
            int salesTable = 1;
            recordProcessed = 0;
            string seed = DateTime.Now.ToString("dd-MM-yyyy") + "_" + Convert.ToString((int)DateTime.Now.Ticks);
            string fileName = "edi_867_" + seed.ToString() + ".edi";
            ediFilepath = destinationFolderName + "\\" + fileName;
            string separator = ConfigManager.GetEDISeperator();
            string endTag = ConfigManager.GetEDIEndTag();
            StringBuilder stringBuilder = new StringBuilder();
            clsEntity_EDI867 _edi = new clsEntity_EDI867();
            int headerRowNo = 0;
            try
            {
                using (StreamWriter writer = new StreamWriter(ediFilepath, true))
                {
                    string ISADate = DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string date = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string time = DateTime.Now.ToString("HHMM");
                    DataTable dtInput = FillDataTable_Params("SELECT ElementName,ElementDefaultValue FROM EDIMapping_867", CommandType.Text, out string message, null);

                    //Transpose DataTable

                    DataTable dtEDI = GenerateTransposedTable(dtInput);
                    string value = "";

                    //Transaction Set Trailer
                    int SE_SegementCount = 0;

                    //Transaction Deals
                    int CTT_TransactionCount = 0;

                    // Set values
                    PropertyDescriptorCollection properties = TypeDescriptor.GetProperties(_edi);
                    foreach (PropertyDescriptor property in properties)
                    {
                        try
                        {
                            if (property != null)
                            {
                                value = dtEDI.Rows[0][property.DisplayName].ToString();
                                Type t = Nullable.GetUnderlyingType(property.PropertyType) ?? property.PropertyType;
                                object safeValue = (value == null) ? null : Convert.ChangeType(value, t);
                                property.SetValue(_edi, safeValue);
                            }
                        }
                        catch { }
                    }

                    _edi.ISA06 = _edi.ISA06.PadRight(15, ' ');
                    _edi.ISA08 = _edi.ISA08.PadRight(15, ' ');
                    _edi.ISA09 = ISADate;
                    _edi.ISA10 = time;

                    _edi.GS04 = date;
                    _edi.GS05 = time;
                    _edi.BIA04 = date;
                    _edi.BPT03 = date;

                    _edi.N102 = dsExcel.Rows[headerRowNo]["Partner Name"].ToString();//Distributer Name
                    _edi.N104 = dsExcel.Rows[headerRowNo]["Partner Code"].ToString();  //Identification Code  - Dynamic

                    _edi.GE02 = _edi.GS06;
                    _edi.IEA02 = _edi.ISA13;

                    string spaceBetweenISA01_ISA03 = new string(' ', 10);
                    string spaceBetweenISA03_ZZ = new string(' ', 10);

                    //ISA - Interchange Control Header
                    stringBuilder.AppendLine("ISA" + separator + _edi.ISA01 + separator + spaceBetweenISA01_ISA03 + separator + _edi.ISA03 + separator + spaceBetweenISA03_ZZ + separator + "ZZ" + separator + _edi.ISA06 + separator + _edi.ISA05 + separator + _edi.ISA08 + separator + _edi.ISA09 + separator + _edi.ISA10 + separator + _edi.ISA11 + separator + _edi.ISA12 + separator + _edi.ISA13 + separator + _edi.ISA14 + separator + _edi.ISA15 + separator + _edi.ISA16 + endTag);
                    SE_SegementCount++;

                    //GS - Functional Group Header
                    stringBuilder.AppendLine("GS" + separator + _edi.GS01 + separator + _edi.GS02 + separator + _edi.GS03 + separator + _edi.GS04 + separator + _edi.GS05 + separator + _edi.GS06 + separator + _edi.GS07 + separator + _edi.GS08 + endTag);
                    SE_SegementCount++;

                    //ST - Transaction Set Header
                    stringBuilder.AppendLine("ST" + separator + _edi.ST01 + separator + _edi.ST02 + endTag);
                    SE_SegementCount++;

                    //BIA - Beginning Segment for Product Transfer and Resale
                    stringBuilder.AppendLine("BPT" + separator + _edi.BPT01 + separator + _edi.BPT02 + separator + _edi.BPT03 + separator + _edi.BPT04 + endTag);
                    SE_SegementCount++;

                    //CUR - Currency
                    _edi.CUR02 = dsExcel.Rows[headerRowNo]["SPA Price Currency"].ToString();
                    stringBuilder.AppendLine("CUR" + separator + _edi.CUR01 + separator + _edi.CUR02 + endTag);
                    SE_SegementCount++;

                    //N1
                    stringBuilder.AppendLine("N1" + separator + _edi.N101 + separator + _edi.N102 + separator + _edi.N103 + separator + _edi.N104 + endTag);
                    SE_SegementCount++;

                    //N2
                    stringBuilder.AppendLine("N2" + separator + _edi.N201 + separator + _edi.N202 + endTag);
                    SE_SegementCount++;

                    //PER  - Administrative Communications Contact
                    stringBuilder.AppendLine("PER" + separator + _edi.PER01 + separator + _edi.PER02 + separator + _edi.PER03 + separator + _edi.PER04 + endTag);
                    SE_SegementCount++;

                    //Loop PTD

                    #region Loop PTD

                    int row = 1;
                    for (int i = headerRowNo; i < dsExcel.Rows.Count; i++)
                    {

                        //1 PTD  - Product Transfer and Resale Detail
                        //To indicate the start of detail information relating to the transfer/resale of a product and provide identifying data
                        stringBuilder.AppendLine("PTD" + separator + _edi.PTD01 + endTag);
                        SE_SegementCount++;

                        #region 2 Address
                        // ST - Ship To
                        string N101_ST_Loop = "ST"; //ST - Ship To
                        string N102_ST_Loop = dsExcel.Rows[i]["Reseller Name"].ToString();
                        string N103_ST_Loop = "92"; // 92 - Assigned By Buyer
                        string N104_ST_Loop = dsExcel.Rows[i]["Reseller Number"].ToString(); // Code identifying a party

                        string N301_ST_Loop = ""; // Address Information
                                                  // Geographic Location
                        string N401_ST_Loop = dsExcel.Rows[i]["City"].ToString();
                        string N402_ST_Loop = ""; //State
                        string N403_ST_Loop = dsExcel.Rows[i]["ZipCode"].ToString(); //Postal Code
                        string N404_ST_Loop = dsExcel.Rows[i]["Reseller Country Code"].ToString(); //Country
                        N404_ST_Loop = GetCompanyCode(N404_ST_Loop);
                        //N1 Name 
                        //ST - Ship To
                        stringBuilder.AppendLine("N1" + separator + N101_ST_Loop + separator + N102_ST_Loop + separator + N103_ST_Loop + separator + N104_ST_Loop + endTag);
                        SE_SegementCount++;

                        if (N301_ST_Loop != string.Empty)
                        {
                            stringBuilder.AppendLine("N3" + separator + N301_ST_Loop + endTag);
                            SE_SegementCount++;
                        }

                        N401_ST_Loop = N401_ST_Loop == string.Empty ? "NA" : N401_ST_Loop;
                        N402_ST_Loop = N402_ST_Loop == string.Empty ? "NA" : N402_ST_Loop;
                        N403_ST_Loop = N403_ST_Loop == string.Empty ? "NA" : N403_ST_Loop;
                        N404_ST_Loop = N404_ST_Loop == string.Empty ? "NA" : N404_ST_Loop;

                        stringBuilder.AppendLine("N4" + separator + N401_ST_Loop + separator + N402_ST_Loop + separator + N403_ST_Loop + separator + N404_ST_Loop + endTag);
                        SE_SegementCount++;

                        //BT - Bill To
                        string N101_BT_Loop = "BT";
                        string N102_BT_Loop = dsExcel.Rows[i]["Reseller Name"].ToString();
                        string N103_BT_Loop = "92"; // 92 - Assigned By Buyer
                        string N104_BT_Loop = dsExcel.Rows[i]["Reseller Number"].ToString(); // Code identifying a party

                        string N301_BT_Loop = ""; // Address Information
                                                  // Geographic Location
                        string N401_BT_Loop = dsExcel.Rows[i]["City"].ToString(); ; //City
                        string N402_BT_Loop = ""; //State
                        string N403_BT_Loop = dsExcel.Rows[i]["ZipCode"].ToString(); //Postal Code
                        string N404_BT_Loop = dsExcel.Rows[i]["Reseller Country Code"].ToString(); //Country
                        N404_BT_Loop = GetCompanyCode(N404_BT_Loop);

                        //N1 Name 
                        //ST - Ship To
                        stringBuilder.AppendLine("N1" + separator + N101_BT_Loop + separator + N102_BT_Loop + separator + N103_BT_Loop + separator + N104_BT_Loop + endTag);
                        SE_SegementCount++;

                        if (N301_BT_Loop != string.Empty)
                        {
                            stringBuilder.AppendLine("N3" + separator + N301_BT_Loop + endTag);
                            SE_SegementCount++;
                        }

                        N401_BT_Loop = N401_BT_Loop == string.Empty ? "NA" : N401_BT_Loop;
                        N402_BT_Loop = N402_BT_Loop == string.Empty ? "NA" : N402_BT_Loop;
                        N403_BT_Loop = N403_BT_Loop == string.Empty ? "NA" : N403_BT_Loop;
                        N404_BT_Loop = N404_BT_Loop == string.Empty ? "NA" : N404_BT_Loop;

                        stringBuilder.AppendLine("N4" + separator + N401_BT_Loop + separator + N402_BT_Loop + separator + N403_BT_Loop + separator + N404_BT_Loop + endTag);
                        SE_SegementCount++;

                        #endregion

                        //3 QTY
                        string QTY01 = "39"; //Shipped Quantity
                        string QTY02 = dsExcel.Rows[i]["Sales Quantity"].ToString(); // Quantity
                        string QTY03 = _edi.QTY03;

                        double dblQTY02 = QTY02 == string.Empty ? 0 : double.Parse(QTY02);
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + dblQTY02.ToString() + separator + QTY03 + endTag);
                        SE_SegementCount++;

                        //3 LINE
                        int LIN01 = row; //Alphanumeric characters ssigned for differentiation within a transaction set
                        string LIN02 = "VP"; // Vendor's (Seller's) Part Number
                        string LIN03 = dsExcel.Rows[i]["SanDisk SKU"].ToString(); // Identifying number for a product or service

                        stringBuilder.AppendLine("LIN" + separator + LIN01.ToString() + separator + LIN02 + separator + LIN03 + endTag); //+ separator + LIN04 + separator + LIN05);
                        SE_SegementCount++;
                        row++;

                        //4 PID - Product/Item Description
                        string PID01 = "F"; //Code indicating the format of a description F = Free Form
                        string PID02 = separator;
                        string PID03 = separator;
                        string PID04 = separator;
                        string PID05 = dsExcel.Rows[i]["Package"].ToString() + " " + dsExcel.Rows[i]["Capacity"].ToString();// A free-form description to clarify the related data elements and their content

                        stringBuilder.AppendLine("PID" + separator + PID01 + PID02 + PID03 + PID04 + PID05 + endTag);
                        SE_SegementCount++;

                        //5 REF - Product/Item Description      
                        //IV - Seller's Invoice Number
                        //PO -  Purchase Order Number
                        stringBuilder.AppendLine("REF" + separator + "IV" + separator + dsExcel.Rows[i]["Invoice Nbr"].ToString() + endTag);
                        SE_SegementCount++;

                        stringBuilder.AppendLine("REF" + separator + "ZZ" + separator + dsExcel.Rows[i]["Quote ID"].ToString() + endTag);
                        SE_SegementCount++;

                        //DTM
                        //003 - Invoice
                        //011 - Shipped 
                        try
                        {
                            string transactionDate = dsExcel.Rows[i]["Transaction Date"].ToString();
                            string[] dateArray = transactionDate.Split('.');
                            //DateTime dt = Convert.ToDateTime(transactionDate);
                            //transactionDate = dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');
                            transactionDate = dateArray[2] + dateArray[1] + dateArray[0];
                            stringBuilder.AppendLine("DTM" + separator + "003" + separator + transactionDate + endTag);
                            SE_SegementCount++;

                            transactionDate = dsExcel.Rows[i]["Ship Date"].ToString();
                            dateArray = transactionDate.Split('.');
                            transactionDate = dateArray[2] + dateArray[1] + dateArray[0];

                            //dt = Convert.ToDateTime(transactionDate);
                            //transactionDate = dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');
                            stringBuilder.AppendLine("DTM" + separator + "011" + separator + transactionDate + endTag);
                            SE_SegementCount++;
                        }
                        catch (Exception ex)
                        {

                        }
                        CTT_TransactionCount++;
                    }

                    #endregion

                    //CTT - Transaction Totals
                    stringBuilder.AppendLine("CTT" + separator + CTT_TransactionCount + endTag);

                    //SE - Transaction Set Trailer
                    stringBuilder.AppendLine("SE" + separator + SE_SegementCount + separator + _edi.ST02 + endTag);

                    //GE - Functional Group Trailer
                    stringBuilder.AppendLine("GE" + separator + _edi.GE01 + separator + _edi.GE02 + endTag);

                    //IEA - Interchnage Control Trailer
                    stringBuilder.AppendLine("IEA" + separator + _edi.IEA01 + separator + _edi.IEA02 + endTag);

                    writer.WriteLine(stringBuilder);
                    writer.Close();
                    recordProcessed = dsExcel.Rows.Count;

                    //Increment Control numbers
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_867 T0 WHERE ElementName = 'ST02'");
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_867 T0 WHERE ElementName = 'ISA13'");
                    GetRecord("UPDATE T0 SET ElementDefaultValue = ElementDefaultValue + 1 FROM EDIMapping_867 T0 WHERE ElementName = 'GS06'");

                }
            }
            catch (Exception ex)
            {
                errorDescription = ex.Message;
                return false;
            }
            return true;
        }

        public bool Generate_846_BK(DataSet dsExcel, out string errorDescription, out string ediFilepath)
        {
            errorDescription = "";
            int inventoryTable = 0;
            string ediFolderPath = ConfigManager.GetDestinationFolderName();
            if (!Directory.Exists(ediFolderPath))
            {
                Directory.CreateDirectory(ediFolderPath);
            }
            //string seed = DateTime.Now.ToString("dd/MM/yyyy") + Convert.ToString((int)DateTime.Now.Ticks);
            string seed = DateTime.Now.ToString("dd-MM-yyyy") + "_" + Convert.ToString((int)DateTime.Now.Ticks);

            int headerRowNo = 2;
            string fileName = "edi_846_" + seed.ToString() + ".edi";
            string separator = ConfigManager.GetEDISeperator();
            string endTag = ConfigManager.GetEDIEndTag();

            ediFilepath = Application.StartupPath + "\\" + ediFolderPath + "\\" + fileName;
            try
            {
                using (StreamWriter writer = new StreamWriter(ediFilepath, true))
                {
                    string ISADate = DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string date = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string time = DateTime.Now.ToString("HHMM");

                    #region ISA - Interchange Control Header

                    string ISA01 = "00"; //Authorization Information Qualifier
                    string ISA03 = "00"; //No Security
                    string ISA05 = "14"; //Interchange ID Qualifier (12 Phone)
                    string ISA06 = ConfigManager.GetISASenderID();// "006995419"; //Sendor Code
                    ISA06 = ISA06.PadRight(15, ' ');

                    string ISA08 = ConfigManager.GetISAReceiverID(); //Interchange Receiver ID (Receiver(Customer) ID) (Dynamic)
                    ISA08 = ISA08.PadRight(15, ' ');

                    string ISA09 = ISADate; //Date
                    string ISA10 = time; //Time
                    string ISA11 = "U"; //Interchange Control Standards (U - U.S. EDI Community)
                    string ISA12 = "00401"; //Interchange Control Version Number (Draft Standards for Trial Use Approved for Publication by ASC X12)
                    string ISA13 = "000000009"; //Interchange Control Number (A control number assigned by the interchange sender)
                    string ISA14 = "0"; //Acknowledgment Requested (0 No Acknowledgment Requested)
                    string ISA15 = ConfigManager.GetEnvironment(); //Usage Indicator (P - Production, T - Test)
                    string ISA16 = "|"; //Component Element Separator (this value must be different than the data element separator and the segment terminator)

                    #endregion

                    #region Group Header 

                    string GS01 = "IB"; // Inventory Advice No
                    string GS02 = ConfigManager.GetISASenderID(); // Sendor Code - Code Agrred By Trading Partner (Dynamic)
                    string GS03 = ConfigManager.GetGSReceiverID_SANDISK(); // Receiver No - Code Agrred By Trading Partner (Dynamic)
                    string GS04 = date;   //Date
                    string GS05 = time; // Time
                    string GS06 = "183235086"; // Group Control Number 
                    string GS07 = "X"; //Responsible Agency Code
                    string GS08 = "004010"; //Draft Standards Approved for Publication
                    #endregion

                    #region ST - Transaction Set Header

                    string ST02 = "90001"; //FunctionalUniqueIdentifier 

                    #endregion

                    #region BIA - Beginning Segment for Inventory Inquiry/Advice

                    string BIA01 = "00";//Original
                    string BIA02 = "DD";//Distributor Inventory Report
                    string BIA03 = "2899573"; //Reference Identification - Dynamic
                    string BIA04 = date; //Date - Dynamic

                    #endregion

                    #region N1 - Name

                    string N102 = dsExcel.Tables[inventoryTable].Rows[headerRowNo]["Partner Name"].ToString();//Distributer Name
                    string N103 = "92"; //Identification Code Qualifier
                    string N104_DS = dsExcel.Tables[inventoryTable].Rows[headerRowNo]["Partner Code"].ToString();  //Identification Code  - Dynamic
                    string N104_WHS = "1028"; //Identification Code - Dynamic

                    #endregion

                    #region N3 - Address Information

                    string N301 = ConfigManager.GetN3Address(); //Location of Named Party (Customer Address) - Dynamic

                    #endregion

                    #region N4 - Geographic Location

                    string N401 = ConfigManager.GetN4City(); // City Name - Dynamic
                    string N402 = ""; // State  Code - Dynamic
                    string N403 = ConfigManager.GetN4ZipCode(); // Postal Code - Dynamic
                    string N404 = ""; // Country - Dynamic

                    #endregion

                    #region Line Identificaion

                    int LIN01 = 1; // Product Service ID
                    string LIN02 = "VP"; // Product Service ID (Vendor's Part Number)
                    string LIN03 = "SD8SB8U"; // Identifying number for a product or service - Dynamic
                    //string LIN04 = "BP"; // Product Service ID (Buyer's Part Number)
                    //string LIN05 = "203465"; // Buyer Part Number - Dynamic

                    #endregion

                    #region PID

                    string PID01 = "F"; // Item Description Type - (F - Free Form)
                    string PID02 = "08"; //  Product Code (08 - Product)
                    string PID05 = ""; // Free Form Description

                    //PID*F*08*Item Descrition
                    #endregion

                    #region QTY

                    string QTY01 = ""; // Type Of Quantity  - Dynamic
                    string QTY02 = ""; //  No of Quantity - Dynamic
                    string QTY03 = "PCS"; // UOM - Dynamic   

                    #endregion

                    #region CTT - Transaction Deals

                    int CTT_TransactionCount = 0;

                    #endregion

                    #region SE - Transaction Set Trailer 

                    int SE_SegementCount = 0;

                    #endregion

                    #region GE - Functional Group Trailer

                    string GE01 = "1"; // Number of Transaction Sets Included
                    string GE02 = GS06; //Assigned number originated and maintained by the sender

                    #endregion

                    #region IEA - Interchange Control Trailer

                    string IEA01 = "1"; // Number of Transaction Sets Included
                    string IEA02 = ISA13; // A control number assigned by the interchange sender

                    #endregion

                    StringBuilder stringBuilder = new StringBuilder();
                    string spaceBetweenISA01_ISA03 = new string(' ', 10);
                    string spaceBetweenISA03_ZZ = new string(' ', 10);

                    stringBuilder.AppendLine("ISA" + separator + ISA01 + separator + spaceBetweenISA01_ISA03 + separator + ISA03 + separator + spaceBetweenISA03_ZZ + separator + "ZZ" + separator + ISA06 + separator + ISA05 + separator + ISA08 + separator + ISA09 + separator + ISA10 + separator + ISA11 + separator + ISA12 + separator + ISA13 + separator + ISA14 + separator + ISA15 + separator + ISA16 + endTag);
                    SE_SegementCount++;

                    //GS - Functional Group Header
                    stringBuilder.AppendLine("GS" + separator + GS01 + separator + GS02 + separator + GS03 + separator + GS04 + separator + GS05 + separator + GS06 + separator + GS07 + separator + GS08 + endTag);
                    SE_SegementCount++;

                    //ST - Transaction Set Header
                    stringBuilder.AppendLine("ST" + separator + "846" + separator + ST02 + endTag);
                    SE_SegementCount++;

                    //BIA - Beginning Segment for Inventory Inquiry/Advice
                    stringBuilder.AppendLine("BIA" + separator + BIA01 + separator + BIA02 + separator + BIA03 + separator + BIA04 + endTag);
                    SE_SegementCount++;

                    //N1 - Name
                    stringBuilder.AppendLine("N1" + separator + "DS" + separator + N102 + separator + N103 + separator + N104_DS + endTag);
                    SE_SegementCount++;

                    N104_WHS = ConfigManager.GetWarehouseCode();  //dsExcel.Tables[inventoryTable].Rows[headerRowNo]["Warehouse Location"].ToString();
                    stringBuilder.AppendLine("N1" + separator + "WH" + separator + "Distributor WAREHOUSE" + separator + N103 + separator + N104_WHS + endTag);
                    SE_SegementCount++;

                    //N3 - Address Information
                    if (N301 != string.Empty)
                    {
                        stringBuilder.AppendLine("N3" + separator + N301 + endTag);
                        SE_SegementCount++;
                    }
                    //N4 - Geographic Location

                    N404 = dsExcel.Tables[inventoryTable].Rows[headerRowNo]["Country"].ToString();

                    N401 = N401 == string.Empty ? "NA" : N401;
                    N402 = N402 == string.Empty ? "NA" : N402;
                    N403 = N403 == string.Empty ? "NA" : N403;
                    N404 = N404 == string.Empty ? "NA" : N404;

                    stringBuilder.AppendLine("N4" + separator + N401 + separator + N402 + separator + N403 + separator + N404 + endTag);
                    SE_SegementCount++;

                    for (int i = headerRowNo; i < dsExcel.Tables[inventoryTable].Rows.Count; i++)
                    {
                        string quantity = dsExcel.Tables[inventoryTable].Rows[i]["Quantity on Hand"].ToString();
                        if (quantity.ToString().ToLower() == "required")
                        {
                            continue;
                        }
                        //LIN - Item Identification
                        LIN01 = i;
                        LIN03 = dsExcel.Tables[inventoryTable].Rows[i]["SanDisk Part Number"].ToString();

                        stringBuilder.AppendLine("LIN" + separator + LIN01 + separator + LIN02 + separator + LIN03 + endTag);
                        SE_SegementCount++;

                        //QTY - Quantity
                        QTY01 = "17";
                        quantity = dsExcel.Tables[inventoryTable].Rows[i]["Quantity on Hand"].ToString();
                        double dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + QTY02 + separator + QTY03 + endTag);
                        SE_SegementCount++;

                        QTY01 = "27";
                        quantity = dsExcel.Tables[inventoryTable].Rows[i]["Quantity in Backorder"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + QTY02 + separator + QTY03 + endTag);
                        SE_SegementCount++;

                        QTY01 = "76";
                        quantity = dsExcel.Tables[inventoryTable].Rows[i]["Quantity Returned to SanDisk"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + QTY02 + separator + QTY03 + endTag);
                        SE_SegementCount++;

                        QTY01 = "63";
                        quantity = dsExcel.Tables[inventoryTable].Rows[i]["Quantity on Order"].ToString();
                        dblquantity = quantity == string.Empty ? 0 : double.Parse(quantity);
                        QTY02 = dblquantity.ToString();
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + QTY02 + separator + QTY03 + endTag);
                        SE_SegementCount++;
                        CTT_TransactionCount++;
                    }
                    //CTT - Transaction Totals
                    stringBuilder.AppendLine("CTT" + separator + CTT_TransactionCount + endTag);

                    //SE - Transaction Set Trailer
                    stringBuilder.AppendLine("SE" + separator + SE_SegementCount + separator + ST02 + endTag);

                    //GE - Functional Group Trailer
                    stringBuilder.AppendLine("GE" + separator + GE01 + separator + GE02 + endTag);

                    //IEA - Interchnage Control Trailer
                    stringBuilder.AppendLine("IEA" + separator + IEA01 + separator + IEA02 + endTag);

                    writer.WriteLine(stringBuilder);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                errorDescription = ex.Message;
                return false;
            }
            return true;
        }

        public bool Generate_867_BK(DataSet dsExcel, out string errorDescription, out string ediFilepath)
        {
            errorDescription = "";
            int salesTable = 1;
            string ediFolderPath = ConfigManager.GetDestinationFolderName();
            if (!Directory.Exists(ediFolderPath))
            {
                Directory.CreateDirectory(ediFolderPath);
            }
            //int seed = (int)DateTime.Now.Ticks;
            string seed = DateTime.Now.ToString("dd-MM-yyyy") + "_" + Convert.ToString((int)DateTime.Now.Ticks);

            string fileName = "edi_867_" + seed.ToString() + ".edi";
            ediFilepath = Application.StartupPath + "\\" + ediFolderPath + "\\" + fileName;
            string separator = ConfigManager.GetEDISeperator();
            string endTag = ConfigManager.GetEDIEndTag();

            int headerRowNo = 2;
            try
            {
                using (StreamWriter writer = new StreamWriter(ediFilepath, true))
                {
                    string ISADate = DateTime.Now.Year.ToString().Substring(2, 2) + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string date = DateTime.Now.Year.ToString() + DateTime.Now.Month.ToString().PadLeft(2, '0') + DateTime.Now.Day.ToString().PadLeft(2, '0');
                    string time = DateTime.Now.ToString("HHMM");

                    #region Not Defined - Done

                    #region ISA - Interchange Control Header

                    //ISA*00* *00* *12*7172557825 *Receive *160802*0717*U*00401*000012886*0*P*>
                    string ISA01 = "00"; //Authorization Information Qualifier
                    string ISA03 = "00"; //No Security
                    string ISA05 = "14"; //Interchange ID Qualifier (12 Phone)
                    string ISA06 = ConfigManager.GetISASenderID();// "006995419"; //Sendor Code
                    ISA06 = ISA06.PadRight(15, ' ');

                    string ISA08 = ConfigManager.GetISAReceiverID(); //Interchange Receiver ID (Receiver(Customer) ID) (Dynamic)
                    ISA08 = ISA08.PadRight(15, ' ');

                    string ISA09 = ISADate; //Date
                    string ISA10 = time; //Time
                    string ISA11 = "U"; //Interchange Control Standards (U - U.S. EDI Community)
                    string ISA12 = "00401"; //Interchange Control Version Number (Draft Standards for Trial Use Approved for Publication by ASC X12)
                    string ISA13 = "000000010"; //Interchange Control Number (A control number assigned by the interchange sender)
                    string ISA14 = "0"; //Acknowledgment Requested (0 No Acknowledgment Requested)
                    string ISA15 = ConfigManager.GetEnvironment();  //Usage Indicator (P - Production, T - Test)
                    string ISA16 = "|"; //Component Element Separator (this value must be different than the data element separator and the segment terminator)

                    #endregion

                    #region Group Header 
                    string GS01 = "PT";
                    string GS02 = ConfigManager.GetISASenderID(); // Sendor Code - Code Agrred By Trading Partner (Dynamic)
                    string GS03 = ConfigManager.GetGSReceiverID_SANDISK(); // Receiver No - Code Agrred By Trading Partner (Dynamic)
                    string GS04 = date;   //Date
                    string GS05 = time; // Time
                    string GS06 = "183235086"; // Group Control Number 
                    string GS07 = "X"; //Responsible Agency Code
                    string GS08 = "004010"; //Draft Standards Approved for Publication
                    #endregion

                    #endregion

                    #region Heading - Done

                    #region ST - Transaction Set Header

                    string ST02 = "100001"; //FunctionalUniqueIdentifier 

                    #endregion

                    #region BPT - Beginning Segment for Product Transfer and Resale

                    string BPT01 = "00";//Original
                    string BPT02 = "2899510";//POS Document ID
                    string BPT03 = date; //Date
                    string BPT04 = "02"; //Report Type Code - Resale

                    #endregion

                    #region Currency

                    string CUR01 = "BY";
                    string CUR02 = "";

                    #endregion

                    #endregion

                    #region Loop N1 (To identify a party by type of organization, name, and code)

                    string N101 = "DS"; //Distributor
                    string N102 = dsExcel.Tables[salesTable].Rows[headerRowNo]["Partner Name"].ToString();//Distributer Name
                    string N103 = "92"; // Code designating the system
                    string N104 = dsExcel.Tables[salesTable].Rows[headerRowNo]["Partner Code"].ToString(); // Distributor ID assigned by Western Digital

                    #region N2 - Additional Name Information

                    string N201 = "DB"; //Code to indicate Distributor Branch - as agreed by WD and Distributor
                    string N202 = "1216"; //Distributor Branch Name - including branch region.

                    #endregion

                    #endregion

                    #region PER - Administrative Communications Contact

                    string PER01 = "BL"; // Contact Function Code - Technical Department
                    string PER02 = ConfigManager.GetEDIContactPersonName(); //EDI contact person name
                    string PER03 = "EM"; //Code identifying the type of communication number
                    string PER04 = ConfigManager.GetEDIContactPersonEmailID();// EDI contact person email

                    #endregion

                    #region Detail

                    #region Loop PTD - Product Transfer and Resale Detail

                    //To indicate the start of detail information relating to the transfer/resale of a product and provide identifying data
                    string PTD01 = "SS"; //Code identifying the type of product transfer - Stock Sale (sell through)

                    #endregion

                    #region Loop ID - N1


                    #endregion

                    #region Loop ID - QTY


                    #endregion

                    #endregion

                    #region Summary - Done

                    #region CTT - Transaction Deals

                    int CTT_TransactionCount = 0;

                    #endregion

                    #region SE - Transaction Set Trailer 

                    int SE_SegementCount = 0;

                    #endregion

                    #endregion

                    #region Not Defined - Done

                    #region GE - Functional Group Trailer

                    string GE01 = "1"; // Number of Transaction Sets Included
                    string GE02 = GS06; //Assigned number originated and maintained by the sender

                    #endregion

                    #region IEA - Interchange Control Trailer

                    string IEA01 = "1"; // Number of Included Functional
                    string IEA02 = ISA13; // Interchange Control Number

                    #endregion

                    #endregion

                    StringBuilder stringBuilder = new StringBuilder();
                    string spaceBetweenISA01_ISA03 = new string(' ', 10);
                    string spaceBetweenISA03_ZZ = new string(' ', 10);

                    //ISA - Interchange Control Header
                    stringBuilder.AppendLine("ISA" + separator + ISA01 + separator + spaceBetweenISA01_ISA03 + separator + ISA03 + separator + spaceBetweenISA03_ZZ + separator + "ZZ" + separator + ISA06 + separator + ISA05 + separator + ISA08 + separator + ISA09 + separator + ISA10 + separator + ISA11 + separator + ISA12 + separator + ISA13 + separator + ISA14 + separator + ISA15 + separator + ISA16 + endTag);
                    SE_SegementCount++;

                    //GS - Functional Group Header
                    stringBuilder.AppendLine("GS" + separator + GS01 + separator + GS02 + separator + GS03 + separator + GS04 + separator + GS05 + separator + GS06 + separator + GS07 + separator + GS08 + endTag);
                    SE_SegementCount++;

                    //ST - Transaction Set Header
                    stringBuilder.AppendLine("ST" + separator + "867" + separator + ST02 + endTag);
                    SE_SegementCount++;

                    //BIA - Beginning Segment for Product Transfer and Resale
                    stringBuilder.AppendLine("BPT" + separator + BPT01 + separator + BPT02 + separator + BPT03 + separator + BPT04 + endTag);
                    SE_SegementCount++;

                    //CUR - Currency
                    CUR02 = dsExcel.Tables[salesTable].Rows[headerRowNo]["SPA Price Currency"].ToString();
                    stringBuilder.AppendLine("CUR" + separator + CUR01 + separator + CUR02 + endTag);
                    SE_SegementCount++;

                    //N1
                    stringBuilder.AppendLine("N1" + separator + N101 + separator + N102 + separator + N103 + separator + N104 + endTag);
                    SE_SegementCount++;

                    //N2
                    stringBuilder.AppendLine("N2" + separator + N201 + separator + N202 + endTag);
                    SE_SegementCount++;

                    //PER  - Administrative Communications Contact
                    stringBuilder.AppendLine("PER" + separator + PER01 + separator + PER02 + separator + PER03 + separator + PER04 + endTag);
                    SE_SegementCount++;

                    //Loop PTD

                    #region Loop PTD

                    int row = 1;
                    for (int i = 2; i < dsExcel.Tables[salesTable].Rows.Count; i++)
                    {

                        //1 PTD  - Product Transfer and Resale Detail
                        //To indicate the start of detail information relating to the transfer/resale of a product and provide identifying data
                        stringBuilder.AppendLine("PTD" + separator + PTD01 + endTag);
                        SE_SegementCount++;

                        #region 2 Address
                        // ST - Ship To
                        string N101_ST_Loop = "ST"; //ST - Ship To
                        string N102_ST_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Name"].ToString();
                        string N103_ST_Loop = "92"; // 92 - Assigned By Buyer
                        string N104_ST_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Number"].ToString(); // Code identifying a party

                        string N301_ST_Loop = ""; // Address Information
                                                  // Geographic Location
                        string N401_ST_Loop = dsExcel.Tables[salesTable].Rows[i]["City"].ToString();
                        string N402_ST_Loop = ""; //State
                        string N403_ST_Loop = dsExcel.Tables[salesTable].Rows[i]["ZipCode"].ToString(); //Postal Code
                        string N404_ST_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Country Code"].ToString(); //Country
                        N404_ST_Loop = GetCompanyCode(N404_ST_Loop);  
                        //N1 Name 
                        //ST - Ship To
                        stringBuilder.AppendLine("N1" + separator + N101_ST_Loop + separator + N102_ST_Loop + separator + N103_ST_Loop + separator + N104_ST_Loop + endTag);
                        SE_SegementCount++;

                        if (N301_ST_Loop != string.Empty)
                        {
                            stringBuilder.AppendLine("N3" + separator + N301_ST_Loop + endTag);
                            SE_SegementCount++;
                        }

                        N401_ST_Loop = N401_ST_Loop == string.Empty ? "NA" : N401_ST_Loop;
                        N402_ST_Loop = N402_ST_Loop == string.Empty ? "NA" : N402_ST_Loop;
                        N403_ST_Loop = N403_ST_Loop == string.Empty ? "NA" : N403_ST_Loop;
                        N404_ST_Loop = N404_ST_Loop == string.Empty ? "NA" : N404_ST_Loop;

                        stringBuilder.AppendLine("N4" + separator + N401_ST_Loop + separator + N402_ST_Loop + separator + N403_ST_Loop + separator + N404_ST_Loop + endTag);
                        SE_SegementCount++;

                        //BT - Bill To
                        string N101_BT_Loop = "BT";
                        string N102_BT_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Name"].ToString();
                        string N103_BT_Loop = "92"; // 92 - Assigned By Buyer
                        string N104_BT_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Number"].ToString(); // Code identifying a party

                        string N301_BT_Loop = ""; // Address Information
                                                  // Geographic Location
                        string N401_BT_Loop = dsExcel.Tables[salesTable].Rows[i]["City"].ToString(); ; //City
                        string N402_BT_Loop = ""; //State
                        string N403_BT_Loop = dsExcel.Tables[salesTable].Rows[i]["ZipCode"].ToString(); //Postal Code
                        string N404_BT_Loop = dsExcel.Tables[salesTable].Rows[i]["Reseller Country Code"].ToString(); //Country
                        N404_BT_Loop = GetCompanyCode(N404_BT_Loop);

                        //N1 Name 
                        //ST - Ship To
                        stringBuilder.AppendLine("N1" + separator + N101_BT_Loop + separator + N102_BT_Loop + separator + N103_BT_Loop + separator + N104_BT_Loop + endTag);
                        SE_SegementCount++;

                        if (N301_BT_Loop != string.Empty)
                        {
                            stringBuilder.AppendLine("N3" + separator + N301_BT_Loop + endTag);
                            SE_SegementCount++;
                        }

                        N401_BT_Loop = N401_BT_Loop == string.Empty ? "NA" : N401_BT_Loop;
                        N402_BT_Loop = N402_BT_Loop == string.Empty ? "NA" : N402_BT_Loop;
                        N403_BT_Loop = N403_BT_Loop == string.Empty ? "NA" : N403_BT_Loop;
                        N404_BT_Loop = N404_BT_Loop == string.Empty ? "NA" : N404_BT_Loop;

                        stringBuilder.AppendLine("N4" + separator + N401_BT_Loop + separator + N402_BT_Loop + separator + N403_BT_Loop + separator + N404_BT_Loop + endTag);
                        SE_SegementCount++;

                        #endregion

                        //3 QTY
                        string QTY01 = "39"; //Shipped Quantity
                        string QTY02 = dsExcel.Tables[salesTable].Rows[i]["Sales Quantity"].ToString(); // Quantity
                        string QTY03 = "PCS";

                        double dblQTY02 = QTY02 == string.Empty ? 0 : double.Parse(QTY02);
                        stringBuilder.AppendLine("QTY" + separator + QTY01 + separator + dblQTY02.ToString() + separator + QTY03 + endTag);
                        SE_SegementCount++;

                        //3 LINE
                        int LIN01 = row; //Alphanumeric characters ssigned for differentiation within a transaction set
                        string LIN02 = "VP"; // Vendor's (Seller's) Part Number
                        string LIN03 = dsExcel.Tables[salesTable].Rows[i]["SanDisk SKU"].ToString(); // Identifying number for a product or service
                        //string LIN04 = "BP"; // Buyer Part Number
                        //string LIN05 = "203465";// Identifying number for a product or service

                        stringBuilder.AppendLine("LIN" + separator + LIN01.ToString() + separator + LIN02 + separator + LIN03 + endTag); //+ separator + LIN04 + separator + LIN05);
                        SE_SegementCount++;
                        row++;

                        //4 PID - Product/Item Description
                        string PID01 = "F"; //Code indicating the format of a description F = Free Form
                        string PID02 = separator;
                        string PID03 = separator;
                        string PID04 = separator;
                        string PID05 = dsExcel.Tables[salesTable].Rows[i]["Package"].ToString() + " " + dsExcel.Tables[salesTable].Rows[i]["Capacity"].ToString();// A free-form description to clarify the related data elements and their content

                        stringBuilder.AppendLine("PID" + separator + PID01 + PID02 + PID03 + PID04 + PID05 + endTag);
                        SE_SegementCount++;

                        //5 REF - Product/Item Description      
                        //IV - Seller's Invoice Number
                        //PO -  Purchase Order Number
                        stringBuilder.AppendLine("REF" + separator + "IV" + separator + dsExcel.Tables[salesTable].Rows[i]["Invoice Nbr"].ToString() + endTag);
                        SE_SegementCount++;

                        stringBuilder.AppendLine("REF" + separator + "ZZ" + separator + dsExcel.Tables[salesTable].Rows[i]["Quote ID"].ToString() + endTag);
                        SE_SegementCount++;

                        //DTM
                        //003 - Invoice
                        //011 - Shipped 
                        try
                        {
                            string transactionDate = dsExcel.Tables[salesTable].Rows[i]["Transaction Date"].ToString();
                            string[] dateArray = transactionDate.Split('.');
                            //DateTime dt = Convert.ToDateTime(transactionDate);
                            //transactionDate = dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');
                            transactionDate = dateArray[2] + dateArray[1] + dateArray[0];
                            stringBuilder.AppendLine("DTM" + separator + "003" + separator + transactionDate + endTag);
                            SE_SegementCount++;

                            transactionDate = dsExcel.Tables[salesTable].Rows[i]["Ship Date"].ToString();
                            dateArray = transactionDate.Split('.');
                            transactionDate = dateArray[2] + dateArray[1] + dateArray[0];

                            //dt = Convert.ToDateTime(transactionDate);
                            //transactionDate = dt.Year.ToString() + dt.Month.ToString().PadLeft(2, '0') + dt.Day.ToString().PadLeft(2, '0');
                            stringBuilder.AppendLine("DTM" + separator + "011" + separator + transactionDate + endTag);
                            SE_SegementCount++;
                        }
                        catch (Exception ex)
                        {

                        }
                        CTT_TransactionCount++;
                    }

                    #endregion

                    //CTT - Transaction Totals
                    stringBuilder.AppendLine("CTT" + separator + CTT_TransactionCount + endTag);

                    //SE - Transaction Set Trailer
                    stringBuilder.AppendLine("SE" + separator + SE_SegementCount + separator + ST02 + endTag);

                    //GE - Functional Group Trailer
                    stringBuilder.AppendLine("GE" + separator + GE01 + separator + GE02 + endTag);

                    //IEA - Interchnage Control Trailer
                    stringBuilder.AppendLine("IEA" + separator + IEA01 + separator + IEA02 + endTag);

                    writer.WriteLine(stringBuilder);
                    writer.Close();
                }
            }
            catch (Exception ex)
            {
                errorDescription = ex.Message;
            }
            return true;
        }

        public bool Insert_Upload_Log(string ediFormat, string fileName, string logStatus, string errorDescription, int recordProcessed)
        {
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[5];
                sqlParameters[0] = new SqlParameter("@EDIFormat", SqlDbType.VarChar);
                sqlParameters[0].Value = ediFormat;

                sqlParameters[1] = new SqlParameter("@FileName", SqlDbType.VarChar);
                sqlParameters[1].Value = fileName;

                sqlParameters[2] = new SqlParameter("@LogStatus", SqlDbType.VarChar);
                sqlParameters[2].Value = logStatus;

                sqlParameters[3] = new SqlParameter("@ErrorDescription", SqlDbType.VarChar);
                sqlParameters[3].Value = errorDescription;

                sqlParameters[4] = new SqlParameter("@RecordProcessed", SqlDbType.Int);
                sqlParameters[4].Value = recordProcessed;

                string message = string.Empty;
                FillDataset_Params("Proc_Insert_UploadLog", CommandType.StoredProcedure, out message, sqlParameters);
                if (message == string.Empty)
                {
                    return true;
                }
                else
                {
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
        }

        public bool Check_Duplicate_FileName(string fileName)
        {
            try
            {
                SqlParameter[] sqlParameters = new SqlParameter[1];
                sqlParameters[0] = new SqlParameter("@FileName", SqlDbType.VarChar);
                sqlParameters[0].Value = fileName;

                string message = string.Empty;
                DataSet ds = FillDataset_Params("Proc_Check_Duplicate_FileName", CommandType.StoredProcedure, out message, sqlParameters);
                if (message == string.Empty)
                {
                    message = ds.Tables[0].Rows[0][0].ToString();
                    if (message == "1")
                    {
                        return true;
                    }
                    return false;
                }
            }
            catch (Exception ex)
            {
                throw ex;
            }
            return false;
        }

        public bool GetAllExcelFilesFromSourceLocation(out string message)
        {
            message = "";
            var sourceLocation = ConfigManager.GetSource_Location();
            var host = ConfigManager.GetSource_Host();
            var port = ConfigManager.GetSource_Port();
            var username = ConfigManager.GetSource_Username();
            var password = ConfigManager.GetSource_Password();
            var tempFolder = ConfigManager.GetTempFolderPath();
            string localPath = Application.StartupPath + "\\" + tempFolder + "\\";

            if (!Directory.Exists(localPath))
            {
                Directory.CreateDirectory(localPath);
            }


            using (var client = new Renci.SshNet.SftpClient(host, port, username, password))
            {
                client.Connect();
                if (client.IsConnected)
                {
                    string dirName = ConfigManager.GetSource_FolderName();
                    var remoteDirectory = "//" + dirName + "//";
                    var files = client.ListDirectory(dirName);
                    foreach (var file in files)
                    {
                        string remoteFileName = file.Name;
                        using (Stream file1 = File.OpenWrite(localPath + remoteFileName))
                        {
                            client.DownloadFile(remoteDirectory + remoteFileName, file1);
                        }
                    }
                    client.Disconnect();
                }
                else
                {
                    message = "SFTP couldn't connect";
                    return false;
                }
            }

            return true;
        }

        public bool CheckFolderExistOnSFTP(out string message)
        {
            try
            {
                message = "";
                var host = ConfigManager.GetDestination_Host();
                var port = ConfigManager.GetDestination_Port();
                var username = ConfigManager.GetDestination_Username();
                var password = ConfigManager.GetDestination_Password();

                // path for file you want to upload
                //var uploadFolder = ConfigManager.GetDestinationFolderName();
                var uploadFolder = ConfigManager.GetDestinationFolderName();
                using (var client = new Renci.SshNet.SftpClient(host, port, username, password))
                {
                    client.Connect();
                    if (client.IsConnected)
                    {
                        client.ChangeDirectory(uploadFolder);
                        client.Disconnect();
                        return true;
                    }
                    else
                    {
                        message = "SFTP connection failed";
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }


        public bool UploadEDIFileOnSFTP(string filePath, out string message)
        {
            try
            {
                message = "";
                var host = ConfigManager.GetDestination_Host();
                var port = ConfigManager.GetDestination_Port();
                var username = ConfigManager.GetDestination_Username();
                var password = ConfigManager.GetDestination_Password();

                // path for file you want to upload
                var uploadFile = filePath;
                var uploadFolder = ConfigManager.GetDestinationFolderName();
                using (var client = new Renci.SshNet.SftpClient(host, port, username, password))
                {
                    client.Connect();
                    if (client.IsConnected)
                    {
                        using (var fileStream = new FileStream(uploadFile, FileMode.Open))
                        {
                            client.ChangeDirectory(uploadFolder);
                            client.BufferSize = 4 * 1024; // bypass Payload error large files
                            client.UploadFile(fileStream, Path.GetFileName(uploadFile));
                        }
                        client.Disconnect();
                        return true;
                    }
                    else
                    {
                        message = "SFTP connection failed";
                        return false;
                    }
                }
            }
            catch (Exception ex)
            {
                message = ex.Message;
                return false;
            }
        }

        public void MoveSourceExcelFileUsingSFTP(string sourceFileName)
        {
            var host = ConfigManager.GetDestination_Host();
            var port = ConfigManager.GetDestination_Port();
            var username = ConfigManager.GetDestination_Username();
            var password = ConfigManager.GetDestination_Password();

            // path for file you want to upload
            var sourceFolder = "//" + ConfigManager.GetSource_FolderName() + "//";
            var destinationFolder = "//" + ConfigManager.GetProcessedFolderName() + "//";
            string sourceFilePath = sourceFolder + sourceFileName;
            string destinationFilePath = destinationFolder + sourceFileName;
            using (var client = new Renci.SshNet.SftpClient(host, port, username, password))
            {
                client.Connect();
                if (client.IsConnected)
                {
                    var inFile = client.Get(sourceFilePath);
                    inFile.MoveTo(destinationFilePath);
                    client.Disconnect();
                }
                else
                {
                    MessageBox.Show("I couldn't connect");
                }
            }
        }

        public string GetCompanyCode(string countryName)
        {
            string code = GetRecord("SELECT Code FROM CountryMaster WHERE Description ='" + countryName + "'");
            return code;
        }

        public DataTable GenerateTransposedTable(DataTable inputTable)
        {
            DataTable outputTable = new DataTable();
            try
            {
                // Add columns by looping rows

                // Header row's first column is same as in inputTable
                outputTable.Columns.Add(inputTable.Columns[0].ColumnName.ToString().Trim().Replace("\"", ""));

                // Header row's second column onwards, 'inputTable's first column taken
                foreach (DataRow inRow in inputTable.Rows)
                {
                    string newColName = inRow[0].ToString().Trim().Replace("\"", "");
                    try
                    {
                        outputTable.Columns.Add(newColName);
                    }
                    catch { }
                }

                // Add rows by looping columns        
                for (int rCount = 1; rCount <= inputTable.Columns.Count - 1; rCount++)
                {
                    DataRow newRow = outputTable.NewRow();

                    // First column is inputTable's Header row's second column
                    newRow[0] = inputTable.Columns[rCount].ColumnName.ToString();
                    for (int cCount = 0; cCount <= inputTable.Rows.Count - 1; cCount++)
                    {
                        try
                        {
                            string colValue = inputTable.Rows[cCount][rCount].ToString();
                            newRow[cCount + 1] = colValue;
                        }
                        catch { }
                    }
                    outputTable.Rows.Add(newRow);
                }


            }
            catch (Exception ex)
            {
                StringBuilder sbColumns = new StringBuilder();
                for (int i = 0; i < inputTable.Columns.Count; i++)
                {
                    sbColumns.Append(" ," + inputTable.Columns[i].ToString());
                }
                return null;
            }
            return outputTable;
        }

        public bool checkDBConnection(out string errorDescription)
        {
            errorDescription = string.Empty;
            try
            {
                CheckDBConnection();
                return true;
            }
            catch (Exception ex)
            {
                errorDescription = ex.Message;
                return false;
            }
        }
    }
}

