﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDI.Entity
{
    public class clsEntity_EDI846
    {
        public string ISA01 { get; set; }
        public string ISA03 { get; set; }
        public string ISA05 { get; set; }
        public string ISA06 { get; set; }

        public string ISA08 { get; set; }
        public string ISA09 { get; set; }
        public string ISA10 { get; set; }
        public string ISA11 { get; set; }
        public string ISA12 { get; set; }
        public string ISA13 { get; set; }
        public string ISA14 { get; set; }
        public string ISA15 { get; set; }
        public string ISA16 { get; set; }
        public string GS01 { get; set; }
        public string GS02 { get; set; }
        public string GS03 { get; set; }
        public string GS04 { get; set; }
        public string GS05 { get; set; }
        public string GS06 { get; set; }
        public string GS07 { get; set; }
        public string GS08 { get; set; }
        public string ST01 { get; set; }
        public string ST02 { get; set; }
        public string BIA01 { get; set; }
        public string BIA02 { get; set; }
        public string BIA03 { get; set; }
        public string BIA04 { get; set; }
        public string N102 { get; set; }
        public string N103 { get; set; }
        public string N104_DS { get; set; }
        public string N104_WHS { get; set; }
        public string N301 { get; set; }
        public string N401 { get; set; }
        public string N402 { get; set; }
        public string N403 { get; set; }
        public string N404 { get; set; }
        public string LIN01 { get; set; }
        public string LIN02 { get; set; }
        public string LIN03 { get; set; }
        public string LIN04 { get; set; }
        public string LIN05 { get; set; }
        public string PID01 { get; set; }
        public string PID02 { get; set; }
        public string PID05 { get; set; }
        public string QTY01 { get; set; }
        public string QTY02 { get; set; }
        public string QTY03 { get; set; }
        public string CTT { get; set; }
        public string SE { get; set; }
        public string GE01 { get; set; }
        public string GE02 { get; set; }
        public string IEA01 { get; set; }
        public string IEA02 { get; set; }



    }
}