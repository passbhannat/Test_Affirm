﻿using General.Classes;
using General.Extensions;
using SAPbouiCOM;
using System;
using System.Text;

namespace PackingSlip.Custom_Form
{
    class clsPackingSlip : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.ComboBox oCombo;
        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        SAPbouiCOM.Matrix oMatrix;
        StringBuilder sbQuery = new StringBuilder();
        SAPbobsCOM.Recordset oRs;
        public const string headerTable = "@PACKSLIP";
        public const string rowTable = "@PACKSLIP1";
        public const string menuID = "PACKSLIP";

        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {

                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.BeforeAction == true)
            {
                try
                {
                    oForm = oApplication.Forms.ActiveForm;
                }
                catch { }
                if (pVal.MenuUID == "519" || pVal.MenuUID == "520" || pVal.MenuUID == "521" || pVal.MenuUID == "6657" || pVal.MenuUID == "7169" || pVal.MenuUID == "7176")//Preview Menu
                {
                    clsVariables.DocEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue(CommonFields.DocEntry, 0);
                    return;
                }
            }
        }



        #endregion

        public void LoadForm(string formMenuID, string baseEntry)
        {
            string Active = string.Empty;
            objclsCommon.LoadXML(formMenuID, string.Empty, string.Empty, SAPbouiCOM.BoFormMode.fm_ADD_MODE);
            oForm = oApplication.Forms.ActiveForm;
            string reportType = objclsCommon.SelectRecord(objclsCommon.GetReportTypeQuery(menuID));
            if (reportType != string.Empty)
            {
                oForm.ReportType = reportType;
            }

            string isRecordExists = objclsCommon.SelectRecord("SELECT DocEntry FROM \"" + headerTable + "\" WHERE U_BaseEn = '" + baseEntry + "' ");
            if (isRecordExists != "")
            {
                oForm.Mode = BoFormMode.fm_FIND_MODE;
                oEdit = oForm.Items.Item("U_BaseEn").Specific;
                oEdit.String = baseEntry;
                oForm.Items.Item("1").Click(BoCellClickType.ct_Regular);
            }
            else
            {
                string baseNo = objclsCommon.SelectRecord("SELECT DocNum FROM ODLN WHERE DocEntry = '" + baseEntry + "' ");
                //string noofrows = objclsCommon.SelectRecord("SELECT U_CON_FACT FROM DLN1 WHERE DocEntry = '" + baseEntry + "' ");
                //int iNoofrows = noofrows == string.Empty ? 1 : int.Parse(noofrows);
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_BaseEn", 0, baseEntry);
                oForm.DataSources.DBDataSources.Item(headerTable).SetValue("U_BaseNo", 0, baseNo);
                oMatrix = oForm.Items.Item("mtx1").Specific;
                oMatrix.FlushToDataSource();
                oDbDataSource = oForm.DataSources.DBDataSources.Item(rowTable);
                oDbDataSource.Clear();

                sbQuery = new StringBuilder();
                sbQuery.Append(" SELECT T0.U_CON_FACT,T1.U_colour,T1.U_surface_finish,T1.U_Edges,T1.U_Thickness,T1.U_size,T1.U_pcs_per_PACK  ");
                sbQuery.Append(" FROM DLN1 T0  ");
                sbQuery.Append(" INNER JOIN OITM T1 ON T0.ItemCode = T1.ItemCode  ");
                sbQuery.Append(" WHERE T0.DocEntry = '" + baseEntry + "' ORDER BY T0.LineNum ");
                oRs = objclsCommon.returnRecord(sbQuery.ToString());

                int lineId = 0;
                while (!oRs.EoF)
                {
                    string noofrows = oRs.Fields.Item("U_CON_FACT").Value.ToString();
                    string colour = oRs.Fields.Item("U_colour").Value.ToString();
                    string surface_finish = oRs.Fields.Item("U_surface_finish").Value.ToString();
                    string edges = oRs.Fields.Item("U_Edges").Value.ToString();
                    string thickness = oRs.Fields.Item("U_Thickness").Value.ToString();
                    string size = oRs.Fields.Item("U_size").Value.ToString();
                    string pcsperpack = oRs.Fields.Item("U_pcs_per_PACK").Value.ToString();
                    string desc = colour + " " + surface_finish + " " + edges + " " + thickness;
                    int iNoofrows = noofrows == string.Empty ? 1 : int.Parse(noofrows);
                    for (int j = 0; j < iNoofrows; j++)
                    {
                        oDbDataSource.InsertRecord(lineId);
                        oDbDataSource.SetValue("LineId", lineId, (lineId + 1).ToString());
                        oDbDataSource.SetValue("U_PackNo", lineId, (lineId + 1).ToString());
                        oDbDataSource.SetValue("U_Desc", lineId, desc);
                        oDbDataSource.SetValue("U_Size", lineId, size);
                        oDbDataSource.SetValue("U_PcCrate", lineId, pcsperpack);
                        lineId++;
                        //oDbDataSource.SetValue("LineId", i, (i + 1).ToString());
                    }
                    oRs.MoveNext();
                }
                oMatrix.LoadFromDataSource();
            }
            oForm.Items.Item("U_BaseEn").EnableinFindMode();
            oForm.Items.Item("U_BaseNo").EnableinFindMode();
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FindRecord), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.AddRecord), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.FirstRecord), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.LastRecord), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.NextRecord), false);
            oForm.EnableMenu(Convert.ToString((int)SAPMenuEnum.PreviousRecord), false);

        }
    }
}
