﻿using EDI.Classes;
using EDI.Entity;
using EDI.Forms;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EDI
{
    public partial class EDIForm : Form
    {
        public EDIForm()
        {
            InitializeComponent();
            GenerateEDI();
            ExitApplication();
        }

        private void GenerateEDI()
        {
            bool isFileGeneratedSuccessfully = false;
            string processedFolder = ConfigManager.GetProcessedFolderName();
            //string destiationFolder = ConfigManager.GetDestinationFolderName();

            string errorDescription = string.Empty;
            Helpers helpers = new Helpers();
            string errorMessage = "";

            #region DB Connection

            if (helpers.checkDBConnection(out errorMessage) == false)
            {
                SendMail("Database Setup failed: " + errorMessage, "", false);
                return;
            }

            #endregion

            #region EDI Configuration Setup

            var sourceLocation = ConfigManager.GetSource_Location();
            string excelFolderPath = "";

            // Get All Excel files from source location
            if (sourceLocation.ToLower() == FileLocationType.Local.ToString().ToLower())
            {
                excelFolderPath = ConfigManager.GetSource_LocalPath() + "\\" + ConfigManager.GetSource_FolderName() + "\\";
                processedFolder = ConfigManager.GetSource_LocalPath() + "\\" + processedFolder + "\\";
                //destiationFolder = ConfigManager.GetSource_LocalPath() + "\\" + destiationFolder + "\\";                
            }
            else if (sourceLocation.ToLower() == FileLocationType.SFTP.ToString().ToLower())
            {
                helpers.GetAllExcelFilesFromSourceLocation(out errorMessage);
                excelFolderPath = Application.StartupPath + "\\" + ConfigManager.GetTempFolderPath() + "\\";
                processedFolder = Application.StartupPath + "\\" + processedFolder + "\\";
                //destiationFolder = Application.StartupPath + "\\" + destiationFolder + "\\";
            }
            else
            {
                SendMail("Wrong EDI configuration setup", "", false);
                return;
            }

            #endregion

            #region SFTP Directory Exists

            if (!Directory.Exists(processedFolder))
            {
                Directory.CreateDirectory(processedFolder);
            }

            DirectoryInfo d = new DirectoryInfo(excelFolderPath);
            FileInfo[] Files = d.GetFiles("*.xls");

            if (Files.Count() == 0)
            {
                helpers.Insert_Upload_Log("File Not found", "", Convert.ToString((int)Status.Error), "No file found to process", 0);
                SendMail("No file found to process", "", false);
                return;
            }

            if (helpers.CheckFolderExistOnSFTP(out errorMessage) == false)
            {
                helpers.Insert_Upload_Log("SFTP Directory does not exists", "", Convert.ToString((int)Status.Error), errorMessage, 0);
                SendMail("SFTP Issues: " + errorMessage, "", false);
                return;
            }

            #endregion

            StringBuilder sbError = new StringBuilder();
            List<clsEntity_EDI> ediList = new List<clsEntity_EDI>();
            int i = 0;
            string sourceFileName = "";
            string sourceFilePath = "";
            string processedFilePath = "";
            string ediFormat = "";
            bool isUploaded = false;
            DataTable dtExcel;
            string edi846_SheetName = ConfigManager.GetEDI846_SheetName();
            string edi867_SheetName = ConfigManager.GetEDI867_SheetName();
            foreach (FileInfo file in Files)
            {
                string ediFilePath = "";
                string ediFileName = "";
                int recordProcessed = 0;
                sourceFileName = file.Name;
                sourceFilePath = file.FullName;
                if (helpers.Check_Duplicate_FileName(sourceFileName) == true)
                {
                    helpers.Insert_Upload_Log("Duplicate File", sourceFileName, Convert.ToString((int)Status.Error), "Duplicate file Name", 0);
                    continue;
                }

                DataTable dataTable_846 = new DataTable();
                ediFormat = "846";
                ediList.Add(new clsEntity_EDI { FileName = sourceFileName });

                if (helpers.ReadExcelFile(sourceFilePath, edi846_SheetName, out dtExcel) == true)
                {
                    var rows = dtExcel.AsEnumerable().Where(t0 => t0.Field<String>("Quantity on Hand") != null && t0.Field<String>("Quantity on Hand").ToLower() != "required");
                    try
                    {
                        if (rows.Any())
                        {
                            dataTable_846 = rows.CopyToDataTable();
                        }
                    }
                    catch (Exception ex)
                    {
                        helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), ex.Message, 0);
                    }

                    if (dataTable_846.Rows.Count > 0)
                    {
                        isFileGeneratedSuccessfully = helpers.Generate_846(dataTable_846, processedFolder, out errorDescription, out ediFilePath, out recordProcessed);
                        if (isFileGeneratedSuccessfully == true)
                        {
                            ediFileName = Path.GetFileName(ediFilePath);
                            isUploaded = helpers.UploadEDIFileOnSFTP(ediFilePath, out errorDescription);
                            if (isUploaded == true)
                            {
                                helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Success), string.Empty, recordProcessed);
                                ediList[i].RecordCount_846 = recordProcessed;
                            }
                            else
                            {
                                helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
                            }
                        }
                        else
                        {
                            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
                            sbError.AppendLine(errorDescription);
                        }
                    }
                }
                ediList[i].RecordCount_846 = recordProcessed;

                DataTable dataTable_867 = new DataTable();
                ediFormat = "867";
                recordProcessed = 0;
                if (helpers.ReadExcelFile(sourceFilePath, edi867_SheetName, out dtExcel) == true)
                {
                    var rows = dtExcel.AsEnumerable().Where(t0 => t0.Field<String>(0) != null && t0.Field<String>(0).ToLower() != "required");
                    try
                    {
                        if (rows.Any())
                        {
                            dataTable_867 = rows.CopyToDataTable();
                        }
                    }
                    catch (Exception ex)
                    {
                        helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), ex.Message, 0);
                    }
                    if (dataTable_867.Rows.Count > 0)
                    {
                        isFileGeneratedSuccessfully = helpers.Generate_867(dataTable_867, processedFolder, out errorDescription, out ediFilePath, out recordProcessed);
                        if (isFileGeneratedSuccessfully == true)
                        {
                            ediFileName = Path.GetFileName(ediFilePath);
                            isUploaded = helpers.UploadEDIFileOnSFTP(ediFilePath, out errorDescription);
                            if (isUploaded == true)
                            {
                                helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Success), string.Empty, recordProcessed);
                                ediList[i].RecordCount_867 = recordProcessed;
                            }
                            else
                            {
                                helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
                            }
                        }
                        else
                        {
                            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
                            sbError.AppendLine(errorDescription);
                        }
                    }
                }

                ediList[i].RecordCount_867 = recordProcessed;

                #region Move File To Processed Folder

                //if (isUploaded == true)
                //{
                processedFilePath = processedFolder + sourceFileName;
                if (sourceLocation.ToLower() == FileLocationType.Local.ToString().ToLower())
                {
                    System.IO.File.Move(sourceFilePath, processedFilePath);
                }
                else
                {
                    helpers.MoveSourceExcelFileUsingSFTP(sourceFileName);
                    System.IO.File.Move(sourceFilePath, processedFilePath);
                }
                //}

                #endregion

                i++;
            }

            StringBuilder sbBody = new StringBuilder();

            sbBody.AppendLine("<table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + ">");
            sbBody.AppendLine("<tr bgcolor='#4da6ff'><td><b>File Name</b></td><td> <b> 846 Format Record Processed </b> </td><td> <b> 867 Format Record Processed </b> </td></tr>");
            for (int k = 0; k < ediList.Count; k++)
            {
                sbBody.AppendLine("<tr><td align ='center'>" + ediList[k].FileName + "</td> <td align ='center'>" + ediList[k].RecordCount_846 + "  </td><td align ='center' >" + ediList[k].RecordCount_867.ToString() + "  </td></tr>");
            }

            sbBody.AppendLine("</table>");
            SendMail(sbBody.ToString(), ediList[0].FileName, true);


            #region Delete All temp files 

            //System.IO.DirectoryInfo di = new DirectoryInfo(excelFolderPath);
            //foreach (FileInfo file in di.GetFiles())
            //{
            //    file.Delete();
            //}

            System.IO.DirectoryInfo di = new DirectoryInfo(processedFolder);
            foreach (FileInfo file in di.GetFiles())
            {
                if (file.FullName.Contains(".edi"))
                {
                    file.Delete();
                }
            }

            #endregion
        }

        private void SendMail(string body, string fileName, bool success)
        {
            clsSendMail objclsSendMail = new clsSendMail();
            string toMail = ConfigManager.GetToMail();
            string fromMail = ConfigManager.GetSMTP_Username();
            string ccMail = "";
            string bccMail = "";
            string subject = "";
            if (success == true)
            {
                subject = "EDI File Generation Successful " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
            }
            else
            {
                subject = "EDI File Generation Failed " + DateTime.Now.ToShortDateString() + " " + DateTime.Now.ToShortTimeString();
            }
            string attachment = "";
            string errorMessage = "";
            bool sendSuccess = objclsSendMail.sendMail(toMail, fromMail, ccMail, bccMail, subject, body, attachment, out errorMessage);
            if (sendSuccess == false)
            {
                Helpers helpers = new Helpers();
                helpers.Insert_Upload_Log("Send Mail", fileName, Convert.ToString((int)Status.Error), errorMessage, 0);
            }
        }

        private void ExitApplication()
        {
            System.Environment.Exit(-1);
        }

        private void BtnEDI_Click(object sender, EventArgs e)
        {

        }
    }
}

#region Commented
/*
private void btnEDI_Click(object sender, EventArgs e)
{
    bool isFileGeneratedSuccessfully = false;
    string dailyUploadFolder = ConfigManager.GetSourceFolderPath();
    string processedFolder = ConfigManager.GetProcessedFolderPath();
    string errorDescription = string.Empty;

    Helpers.GetAllFilesFromDirectory(dailyUploadFolder);

    //if (!Directory.Exists(dailyUploadFolder))
    //{
    //    MessageBox.Show("To be processed folder does not exist!");
    //    return;
    //}
    var tempFolder = ConfigManager.GetTempFolderPath();
    string localPath = Application.StartupPath + "\\" + tempFolder + "\\";
    DirectoryInfo d = new DirectoryInfo(localPath);
    FileInfo[] Files = d.GetFiles("*.xls");
    DataSet dsExcel = new DataSet();
    Helpers helpers = new Helpers();

    if (Files.Count() == 0)
    {
        MessageBox.Show("No file found to process");
        return;
    }

    string ediFormat = "";
    StringBuilder sbError = new StringBuilder();
    List<clsEntity_EDI> ediList = new List<clsEntity_EDI>();
    int i = 0;
    string sourceFileName = "";
    string sourceFilePath = "";

    foreach (FileInfo file in Files)
    {
        string ediFilePath = "";
        string ediFileName = "";
        int recordProcessed = 0;
        sourceFileName = file.Name;
        sourceFilePath = file.FullName;

        Helpers.ReadExcelFile(sourceFilePath, out dsExcel);
        ediFormat = "846";
        recordProcessed = dsExcel.Tables[0].Rows.Count - 2;
        isFileGeneratedSuccessfully = Helpers.Generate_846(dsExcel, out errorDescription, out ediFilePath);
        if (isFileGeneratedSuccessfully == true)
        {
            ediFileName = Path.GetFileName(ediFilePath);
            Helpers.FileUploadSFTP(ediFilePath);
            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Success), string.Empty, recordProcessed);
            ediList.Add(new clsEntity_EDI { FileName = sourceFileName, RecordCount_846 = recordProcessed });
        }
        else
        {
            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
            sbError.AppendLine(errorDescription);
        }

        ediFormat = "867";
        recordProcessed = dsExcel.Tables[1].Rows.Count - 2;
        isFileGeneratedSuccessfully = Helpers.Generate_867(dsExcel, out errorDescription, out ediFilePath);
        if (isFileGeneratedSuccessfully == true)
        {
            ediFileName = Path.GetFileName(ediFilePath);
            Helpers.FileUploadSFTP(ediFilePath);
            Helpers.MoveSourceFileSFTP(sourceFileName); // Pravin
            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Success), string.Empty, recordProcessed);
            ediList[i].RecordCount_867 = recordProcessed;
        }
        else
        {
            helpers.Insert_Upload_Log(ediFormat, sourceFileName, Convert.ToString((int)Status.Error), errorDescription, 0);
            sbError.AppendLine(errorDescription);
        }
        i++;
    }
    if (isFileGeneratedSuccessfully == true)
    {
        StringBuilder sbBody = new StringBuilder();

        sbBody.AppendLine("<table border=" + 1 + " cellpadding=" + 0 + " cellspacing=" + 0 + " width = " + 400 + ">");
        sbBody.AppendLine("<tr bgcolor='#4da6ff'><td><b>File Name</b></td><td> <b> 846 Format Record Processed </b> </td><td> <b> 867 Format Record Processed </b> </td></tr>");
        for (int k = 0; k < ediList.Count; k++)
        {
            sbBody.AppendLine("<tr><td align ='center'>" + ediList[k].FileName + "</td> <td>" + ediList[k].RecordCount_846 + "  </td><td align ='center' >" + ediList[k].RecordCount_867.ToString() + "  </td></tr>");
        }

        sbBody.AppendLine("</table>");
        SendMail(sbBody.ToString(), ediList[0].FileName);

        MessageBox.Show("File Generated Succefullly");

    }
    else
    {
        MessageBox.Show(sbError.ToString());
    }
}

private void Btn867_Click(object sender, EventArgs e)
{
    bool isFileGeneratedSuccessfully = false;
    string dailyUploadFolder = ConfigManager.GetSourceFolderPath();
    string processedFolder = ConfigManager.GetProcessedFolderPath();
    string errorDescription = string.Empty;
    if (!Directory.Exists(dailyUploadFolder))
    {
        MessageBox.Show("To be processed folder does not exist!");
        return;
    }
    DirectoryInfo d = new DirectoryInfo(dailyUploadFolder);
    FileInfo[] Files = d.GetFiles("*.xls");
    DataSet dsExcel = new DataSet();
    Helpers helpers = new Helpers();
    string ediFormat = "867";
    if (!Directory.Exists(processedFolder))
    {
        Directory.CreateDirectory(processedFolder);
    }

    string ediFilepath = "";

    foreach (FileInfo file in Files)
    {
        Helpers.ReadExcelFile(file.FullName, out dsExcel);
        isFileGeneratedSuccessfully = Helpers.Generate_867(dsExcel, out errorDescription, out ediFilepath);
        if (isFileGeneratedSuccessfully == true)
        {
            string filePath = processedFolder + "\\" + file.Name;
            file.MoveTo(filePath);
            Helpers.FileUploadSFTP(filePath);
            helpers.Insert_Upload_Log(ediFormat, file.Name, Convert.ToString((int)Status.Success), string.Empty, 0);
        }
        else
        {
            helpers.Insert_Upload_Log(ediFormat, file.Name, Convert.ToString((int)Status.Error), errorDescription, 0);
        }
    }
    if (isFileGeneratedSuccessfully == true)
    {
        MessageBox.Show("File Generated Succefullly");
    }
}


    */
#endregion