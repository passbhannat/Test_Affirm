﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDI.Entity
{
    public class clsEntity_EDI867
    {
        public string ISA01 { get; set; }
        public string ISA03 { get; set; }
        public string ISA05 { get; set; }
        public string ISA06 { get; set; }
        public string ISA08 { get; set; }
        public string ISA09 { get; set; }
        public string ISA10 { get; set; }
        public string ISA11 { get; set; }
        public string ISA12 { get; set; }
        public string ISA13 { get; set; }
        public string ISA14 { get; set; }
        public string ISA15 { get; set; }

        public string ISA16 { get; set; }
        public string GS01 { get; set; }
        public string GS02 { get; set; }
        public string GS03 { get; set; }

        public string GS04 { get; set; }
        public string GS05 { get; set; }

        public string GS06 { get; set; }
        public string GS07 { get; set; }
        public string GS08 { get; set; }
        public string ST01 { get; set; }

        public string ST02 { get; set; }
        public string BPT01 { get; set; }
        public string BPT02 { get; set; }
        public string BPT03 { get; set; }
        public string BPT04 { get; set; }
        public string CUR01 { get; set; }
        public string CUR02 { get; set; }

        public string N101 { get; set; }
        public string N102 { get; set; }
        public string N104_DS { get; set; }
        public string N104 { get; set; }

        public string N103 { get; set; }
        public string N201 { get; set; }
        public string N202 { get; set; }
        public string PER01 { get; set; }
        public string PER02 { get; set; }
        public string PER03 { get; set; }
        public string PER04 { get; set; }
        public string PTD01 { get; set; }
        public string GE01 { get; set; }
        public string IEA01 { get; set; }

        public string GE02 { get; set; }
        public string IEA02 { get; set; }
        public string BIA04 { get; set; }
        public string QTY03 { get; set; }

    }
}