﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;

namespace EDI.Entity
{
    public class clsEntity_EmailTemplate
    {
        public int EmailTemplateCode { get; set; }
        public string EmailSubject { get; set; }
        public string EmailBody { get; set; }
    }
}