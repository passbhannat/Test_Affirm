﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace EDI.Classes
{
    public enum Status
    {
        Error = -1,
        Success = 0
    }

    public enum FileLocationType
    {
        Local,
        SFTP
    }
}
