using General;
using General.Classes;
using General.Extensions;
using log4net;
using log4net.Config;
using log4net.Repository.Hierarchy;
using PackingSlip.Custom_Form;
using PackingSlip.Standard_Forms;
using SAPbouiCOM;
using System;
using System.Reflection;

namespace General.Classes
{
    class SAPMain : Connection
    {
        public static ILog logger;
        SAPbouiCOM.Form oForm;

        #region Variables

        clsCommon objclsComman = new clsCommon();
        clsDelivery objclsDelivery = new clsDelivery();
        clsPackingSlip objclsPackingSlip = new clsPackingSlip();

        #endregion

        #region Constructor

        public SAPMain()
        {
            InitLogger();
            ConnectToSAPApplication();
            PrepareMenus();
            PrepareEvents();
        }

        private void PrepareMenus()
        {
            logger.DebugFormat("> {0}", "PrepareMenus");
            objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.UDO.ToString(), SAPCustomFormUIDEnum.UDO.ToDescription(), 5);

            // objclsComman.AddMenu(BoMenuType.mt_POPUP, "43520", "PROD_PLAN", "Production Planning", 16);
            //objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.GENERAL_UDO.ToString(), SAPCustomFormUIDEnum.GENERAL_UDO.ToDescription(), 5);
            //objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.SystemInitialisation), SAPCustomFormUIDEnum.UPDATE_PORTALID.ToString(), SAPCustomFormUIDEnum.UPDATE_PORTALID.ToDescription(), 6);
            //objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.ServiceModule), SAPCustomFormUIDEnum.SERCONTLIST_INVOICE.ToString(), SAPCustomFormUIDEnum.SERCONTLIST_INVOICE.ToDescription(), 5);
            //objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.ServiceModule), SAPCustomFormUIDEnum.SERCONTLIST_PRICE.ToString(), SAPCustomFormUIDEnum.SERCONTLIST_PRICE.ToDescription(), 6);
            //objclsComman.AddMenu(BoMenuType.mt_STRING, Convert.ToString((int)SAPMenuEnum.ServiceModule), SAPCustomFormUIDEnum.SERCONTLIST_SMAIL.ToString(), SAPCustomFormUIDEnum.SERCONTLIST_SMAIL.ToDescription(), 7);

        }

        /// <summary>
        /// Create Event Handler 
        /// </summary>
        private void PrepareEvents()
        {
            logger.DebugFormat("> {0} ", "PrepareEvents");
            oApplication.ItemEvent += new _IApplicationEvents_ItemEventEventHandler(oApplication_ItemEvent);
            oApplication.MenuEvent += new _IApplicationEvents_MenuEventEventHandler(oApplication_MenuEvent);
            oApplication.FormDataEvent += new _IApplicationEvents_FormDataEventEventHandler(oApplication_FormDataEvent);
            oApplication.AppEvent += new _IApplicationEvents_AppEventEventHandler(oApplication_AppEvent);
            oApplication.LayoutKeyEvent += oApplication_LayoutKeyEvent;
        }



        #endregion

        #region Events

        void oApplication_ItemEvent(string FormUID, ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            if (pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
            {
                objclsDelivery.ItemEvent(ref pVal, out BubbleEvent);
            }
            else if (pVal.FormTypeEx == "PACKSLIP")
            {
                objclsPackingSlip.ItemEvent(ref pVal, out BubbleEvent);
            }
        }

        void oApplication_MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                oForm = oApplication.Forms.ActiveForm;
            }
            catch { }
            if (pVal.BeforeAction == true)
            {
                if (pVal.MenuUID == "UDO")
                {
                    objclsComman.CreateDataBase();
                }
                else if (oForm.TypeEx == "PACKSLIP")
                {
                    objclsPackingSlip.MenuEvent(ref pVal, out BubbleEvent);
                }
            }
        }

        void oApplication_FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                if (BusinessObjectInfo.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
                {
                    objclsDelivery.FormDataEvent(ref BusinessObjectInfo, out BubbleEvent);
                }
            }
            catch (Exception ex)
            {
                SAPMain.logger.Error(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message);
                oApplication.StatusBar.SetText(this.GetType().Name + " > " + System.Reflection.MethodBase.GetCurrentMethod().Name + " : " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }

        void oApplication_AppEvent(SAPbouiCOM.BoAppEventTypes EventType)
        {
            switch (EventType)
            {
                case SAPbouiCOM.BoAppEventTypes.aet_ShutDown:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Shutdown Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Runtime.InteropServices.Marshal.ReleaseComObject(oCompany);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_CompanyChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Company changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;

                case SAPbouiCOM.BoAppEventTypes.aet_ServerTerminition:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Server Terminition Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
                case SAPbouiCOM.BoAppEventTypes.aet_LanguageChanged:
                    oApplication.SetStatusBarMessage(System.Reflection.Assembly.GetExecutingAssembly().GetName().Name + " Addon... Language changed Event has been caught" + Environment.NewLine + "Terminating Add On...", BoMessageTime.bmt_Short, false);
                    System.Windows.Forms.Application.Exit();
                    break;
            }
        }

        void oApplication_LayoutKeyEvent(ref LayoutKeyInfo eventInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;

            if (eventInfo.BeforeAction == true)
            {
                if (eventInfo.FormUID.Contains("PACKSLIP"))
                {
                    eventInfo.LayoutKey = clsVariables.DocEntry;
                }
            }
        }
        #endregion

        #region Methods

        /// <summary>
        ///     Configure log4net system based on application configuration setting
        /// </summary>
        private static void InitLogger()
        {
            XmlConfigurator.Configure();
            ((Hierarchy)LogManager.GetRepository()).RaiseConfigurationChanged(EventArgs.Empty);
            logger = LogManager.GetLogger(MethodBase.GetCurrentMethod().DeclaringType);
            logger.Info("Logger initialzed.");
        }

        #endregion
    }
}
