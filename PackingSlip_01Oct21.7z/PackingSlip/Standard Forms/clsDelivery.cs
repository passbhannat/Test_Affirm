﻿using General.Classes;
using PackingSlip.Custom_Form;
using SAPbouiCOM;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PackingSlip.Standard_Forms
{
    class clsDelivery : Connection
    {
        #region Variables

        clsCommon objclsCommon = new clsCommon();

        SAPbouiCOM.DBDataSource oDbDataSource = null;

        SAPbouiCOM.Form oForm;
        SAPbouiCOM.EditText oEdit;
        StringBuilder sbQuery = new StringBuilder();

        const string headerTable = "ODLN";
        #endregion

        #region Events

        public void ItemEvent(ref SAPbouiCOM.ItemEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {
                #region Before_Action == true

                if (pVal.Before_Action == true)
                {
                    try
                    {
                        //oForm = (SAPbouiCOM.Form)oApplication.Forms.Item(pVal.FormUID);
                        if (pVal.EventType == BoEventTypes.et_ITEM_PRESSED)
                        {
                            //Create Form Object
                            if (pVal.ItemUID == "btPS")
                            {
                                oForm = oApplication.Forms.Item(pVal.FormUID);
                                if (oForm.Mode != BoFormMode.fm_OK_MODE)
                                {
                                    oApplication.StatusBar.SetText("Form should be in Ok mode", BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                                    return;
                                }
                                string docEntry = oForm.DataSources.DBDataSources.Item(headerTable).GetValue("DocEntry", 0).Trim();
                                clsPackingSlip _clsPackingSlip = new clsPackingSlip();
                                _clsPackingSlip.LoadForm(clsPackingSlip.menuID, docEntry);
                            }
                        }

                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=true: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion

                #region Before_Action == false

                else if (pVal.Before_Action == false)
                {
                    try
                    {
                        if (pVal.EventType == SAPbouiCOM.BoEventTypes.et_FORM_LOAD && pVal.FormTypeEx == Convert.ToString((int)SAPFormUIDEnum.Delivery))
                        {
                            oForm = oApplication.Forms.Item(pVal.FormUID);
                            CreateControls(oForm);
                        }
                    }
                    catch (Exception ex)
                    {
                        oApplication.StatusBar.SetText("Item Event Before_Action=false: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
                    }
                }

                #endregion
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("Item Event: " + ex.Message, BoMessageTime.bmt_Short, BoStatusBarMessageType.smt_Error);
            }
        }

        public void MenuEvent(ref SAPbouiCOM.MenuEvent pVal, out bool BubbleEvent)
        {
            BubbleEvent = true;
        }

        public void FormDataEvent(ref SAPbouiCOM.BusinessObjectInfo BusinessObjectInfo, out bool BubbleEvent)
        {
            BubbleEvent = true;
            try
            {

                if (BusinessObjectInfo.ActionSuccess == true)
                {
                    if (BusinessObjectInfo.EventType == SAPbouiCOM.BoEventTypes.et_FORM_DATA_LOAD)
                    {
                        oForm = oApplication.Forms.Item(BusinessObjectInfo.FormUID);
                        string docEntry = oForm.DataSources.DBDataSources.Item(0).GetValue("DocEntry", 0);
                        string isRecordExists = objclsCommon.SelectRecord("SELECT DocEntry FROM \"" + clsPackingSlip.headerTable + "\" WHERE U_BaseEn = '" + docEntry + "' ");
                        SAPbouiCOM.Button button = oForm.Items.Item("btPS").Specific;
                        if (isRecordExists != "")
                        {
                            button.Caption = "Open PS";
                        }
                        else
                        { 
                            button.Caption = "Create PS";
                        }
                    }
                }

            }
            catch (Exception ex)
            {
                oApplication.SetStatusBarMessage(ex.Message, BoMessageTime.bmt_Short, false);
            }
        }


        #endregion

        private void CreateControls(SAPbouiCOM.Form oForm)
        {

            try
            {
                SAPbouiCOM.Item oNewItem = oForm.Items.Add("btPS", SAPbouiCOM.BoFormItemTypes.it_BUTTON);
                SAPbouiCOM.Item oItem = oForm.Items.Item(Convert.ToString((int)SAPButtonEnum.Cancel));
                oNewItem.Left = oItem.Left + oItem.Width + 10;
                oNewItem.Top = oItem.Top;
                oNewItem.Height = oItem.Height;
                oNewItem.Width = oItem.Width;
                SAPbouiCOM.Button oButton = (SAPbouiCOM.Button)oNewItem.Specific;
                oButton.Caption = "Create PS";
            }
            catch (Exception ex)
            {
                oApplication.StatusBar.SetText("F_et_FORM_LOAD Item Event Before_Action=false: " + ex.Message, SAPbouiCOM.BoMessageTime.bmt_Short, SAPbouiCOM.BoStatusBarMessageType.smt_Error);
            }
        }
    }
}
